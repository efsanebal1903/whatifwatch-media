# EEVEE hız testi (RTX 4060)

Sahne: `scene\gravity_eevee_test.blend`. Cycles sahnesinin sadeleştirilmiş kopyası.
Karakterler, rig, animasyon ve kameralar aynı. Sadece motor, ışık ve efektler değişti:

| | Cycles sahnesi (`gravity_test.blend`) | EEVEE test sahnesi |
|---|---|---|
| Motor | Cycles (ışın izleme) | EEVEE (rasterize) |
| Örnek sayısı | 24 (uyarlamalı) + OIDN gürültü giderme | 16 TAA, gürültü giderme gerekmez |
| Işıklar | 5 (4 alan + 1 nokta) | 3 alan (pencere, ana ışık, dolgu). Arka kenar ışığı ve lamba nokta ışığı çıkarıldı |
| Dolaylı ışık | 4 sekme (diffuse 2, glossy 2) | Yok. Yerine daha güçlü dolgu ışığı (140 W) ve dünya ışığı (0.6) |
| Gölge | Yumuşak, ışın izlemeli | Gölge haritası: 1 ışın, 4 adım, 0.5 çözünürlük ölçeği |
| Hareket bulanıklığı | Açık (0.5) | Kapalı |
| Alan derinliği (DOF) | 3 kamerada açık | Kapalı |
| Cilt alt-yüzey saçılması (SSS) | Açık (0.12) | Kapalı |
| Subdivision (render) | Seviye 2, 116 nesne | Seviye 1 |

Test bölümü: 97–144. kareler (2 sn). A çekiminin sonunu, kesmeyi ve yakın B çekiminin başını (Max'in yüzü) içeriyor.

## Sıra
1. `A_EEVEE_720p_ONIZLEME.bat`: 1280×720 önizleme.
   Çıktılar `render\eevee_720p.mp4` ve `render\eevee_720p_sonuc.txt`.
   Önce bunu bana gönder. Işık çok karanlık ya da çok açık olursa ayarlarım. EEVEE'de dolaylı ışık olmadığı için ilk denemede parlaklık farklı çıkabilir.
2. `B_EEVEE_1080p_HIZ_OLCUMU.bat`: aynı 48 kare 1920×1080'de.
   `render\eevee_1080p_sonuc.txt` dosyasında şunlar yazar:
   - İlk karenin süresi. Shader derleme dahil olduğu için tek seferlik hazırlık süresidir.
   - Sonraki karelerin ortalama süresi.
   - 13 sn, 8,5 dk ve 9 dk için yalnızca render süresi hesabı.

Bu iki test kısa sürer, uzun render başlatmaz.
