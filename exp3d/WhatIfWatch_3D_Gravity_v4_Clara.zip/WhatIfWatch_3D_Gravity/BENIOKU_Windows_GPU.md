# What If Watch — 3D deneme "Max yerçekimini kontrol ediyor": Windows + RTX 4060 ile render

## Gerekenler
- **Blender 5.x** (ücretsiz). Sahne Blender **5.0.1** ile oluşturuldu ve orada test edildi.
  Kurulu olan 5.2.3 ile çalışması beklenir: 5.1 ve 5.2 Python API notlarında bu betiklerin kullandığı API'lerde kırıcı bir değişiklik görünmüyor.
  Ancak 5.2.3'ü burada çalıştırıp doğrulayamadım. `1_GPU_TEST.bat` bunu da sınar.
- Güncel NVIDIA sürücüsü (Game Ready veya Studio). OptiX için sürücünün güncel olması yeterli, ayrıca CUDA kurmanıza gerek yok.
- Başka eklenti, model, doku veya HDRI gerekmez. Her şey `.blend` dosyasının içinde ya da betiklerle üretiliyor.

## Kurulum
1. ZIP'i örneğin `C:\WIW3D\` klasörüne çıkarın. Yolda Türkçe karakter olmamasını öneririm.
2. `.bat` dosyaları `C:\Program Files\Blender Foundation\` altındaki Blender 5.x klasörünü kendisi bulur ve en yeni sürümü seçer (örneğin 5.2).
   Kullanılan yol pencerenin ilk satırında yazar. Blender başka bir yerdeyse `.bat` içindeki `BLENDER` yolunu düzeltin.

## 1. adım: GPU testi (yaklaşık 1 dakika)
`1_GPU_TEST.bat` dosyasına çift tıklayın.

- Başarılı olursa pencerede `GPU ACIK: OPTIX -> NVIDIA GeForce RTX 4060 ...` satırı görünür.
  Ardından `GPU TEST OK | ... sn/kare | 312 kare tahmini: ... dk` yazar.
- `render\gpu_test\gpu_test_f0150.png` ile `gpu_test_sonuc.txt` oluşur.
- Bu süreyi bana yazarsanız final render süresini net söyleyebilirim.
- `GPU BULUNAMADI` çıkarsa betik CPU'ya **geçmez** ve durur. Bu durumda NVIDIA sürücüsünü güncelleyip tekrar deneyin.

## 2. adım: Önizleme (1286×723, 8 örnek, hareket bulanıklığı yok)
`2_ONIZLEME_720p_GPU.bat`
→ kareler `render\preview\` klasörüne, video `render\MaxGravity_preview_1286x723.mp4` olarak çıkar.

## 3. adım: Final (1920×1080, 24 fps, 312 kare, sahnedeki ayarlarla)
`3_FINAL_1080p_GPU.bat`
→ kareler `render\final\` klasörüne, video `render\MaxGravity_final_1920x1080.mp4` olarak çıkar.

- Sahne ayarları: Cycles, 24 örnek (uyarlamalı, eşik 0.03), OIDN gürültü giderme, hareket bulanıklığı açık, subdivision render seviyesi 2.
- Yarıda kesilirse aynı `.bat`'ı tekrar çalıştırın. Biten kareler atlanır.

## Dosyalar
- `scene\gravity_test.blend`: düzenlenebilir sahne. Kameralar zaman çizelgesindeki işaretlerle bağlı (A: 1–108, B: 109–204, C: 205–312).
  Max'in rig'i: `Max_RIG`. Eller ve ayaklar IK hedefleriyle (`hand_ik.*`, `foot_ik.*`), gövde `pelvis/spine/head` kemikleriyle oynatılıyor.
- `scripts\gpu_common.py`, `gpu_test.py`, `render_gpu.py`, `make_mp4.py`: Windows GPU render betikleri.
- `scripts\source\`: sahneyi sıfırdan üreten kaynak betikler.
  - `wiw3d_lib.py`: geometri ve malzeme yardımcıları.
  - `wiw3d_chars.py`: Clara ve Max.
  - `gravity_scene.py`: oda ve animasyon.
  - `check_motion.py`: ayak kayması, IK kopması ve iç içe geçme kontrolleri.
  - `preview_chars.py`: karakter önizlemeleri.
  - `render_preview.py`: hızlı önizleme profilleri.
  - Örnek: `blender -b -P scripts\source\gravity_scene.py -- yeni.blend`
- `motion_final.json`: bu sahnede çalıştırılan sayısal hareket kontrolünün sonucu.
