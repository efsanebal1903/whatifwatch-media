@echo off
chcp 65001 >nul
cd /d "%~dp0"
if "%BLENDER%"=="" for /d %%D in ("C:\Program Files\Blender Foundation\Blender 5.*") do if exist "%%D\blender.exe" set "BLENDER=%%D\blender.exe"
echo Kullanilan Blender: "%BLENDER%"
if not exist "%BLENDER%" (
  echo Blender bulunamadi: "%BLENDER%"
  echo Blender 5.x'i blender.org'dan kurun ya da bu dosyanin basina: set "BLENDER=C:\...\blender.exe" yazin.
  pause & exit /b 1
)
"%BLENDER%" -b scene\gravity_test.blend -P scripts\render_gpu.py -- preview
"%BLENDER%" -b -P scripts\make_mp4.py -- preview
pause
