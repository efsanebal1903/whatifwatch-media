# Shared helper: switch Cycles to the NVIDIA GPU (OptiX first, CUDA as fallback) and refuse to continue on CPU.
import bpy

import os

def enable_gpu(prefer=('OPTIX', 'CUDA')):
    if os.environ.get('WIW_ALLOW_CPU') == '1':      # only for testing the scripts on a machine without a GPU
        print('UYARI: WIW_ALLOW_CPU=1 -> GPU zorunlulugu atlandi (yalnizca betik testi)')
        return ('CPU', ['test'])
    prefs = bpy.context.preferences.addons['cycles'].preferences
    chosen = None
    for kind in prefer:
        try:
            prefs.compute_device_type = kind
        except TypeError:
            continue                      # this backend is not available on this machine
        prefs.refresh_devices()
        gpus = [d for d in prefs.devices if d.type == kind]
        if gpus:
            for d in prefs.devices:
                d.use = (d.type == kind)  # GPU only (the CPU is not mixed in)
            chosen = (kind, [d.name for d in gpus])
            break
    if chosen is None:
        print('\n*** GPU BULUNAMADI: OptiX/CUDA aygıtı yok. NVIDIA sürücüsünü güncelleyip tekrar deneyin. Render CPU ile YAPILMADI. ***\n')
        raise SystemExit(2)
    for sc in bpy.data.scenes:
        sc.cycles.device = 'GPU'
    print(f'GPU ACIK: {chosen[0]} -> {", ".join(chosen[1])}')
    return chosen
