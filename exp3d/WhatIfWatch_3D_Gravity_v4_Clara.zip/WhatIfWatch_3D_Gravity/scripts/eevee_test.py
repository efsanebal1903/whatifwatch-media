# EEVEE test render with per-frame timing. Run on the PC with the RTX 4060:
# blender.exe -b scene\gravity_eevee_test.blend -P scripts\eevee_test.py -- <720|1080> [first] [last]
# Default section: frames 97-144 (2 s: end of shot A, the cut, start of the close shot B).
# Report: first frame (includes EEVEE shader compilation = one-time preparation) separately from the steady per-frame time.
import sys, os, time
import bpy
argv = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
res = argv[0] if argv else '720'
f0 = int(argv[1]) if len(argv) > 1 else 97
f1 = int(argv[2]) if len(argv) > 2 else 144
tag = argv[3] if len(argv) > 3 else ''
sc = bpy.context.scene
if sc.render.engine != 'BLENDER_EEVEE':
    print('Bu betik EEVEE sahnesi icin: scene\\gravity_eevee_test.blend'); raise SystemExit(2)
sc.render.resolution_x, sc.render.resolution_y = (1280, 720) if res == '720' else (1920, 1080)
sc.render.resolution_percentage = 100
sc.render.image_settings.file_format = 'PNG'
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
name = f'eevee_{res}p{tag}'
out = os.path.join(root, 'render', name); os.makedirs(out, exist_ok=True)
times = []
for f in range(f0, f1 + 1):
    sc.frame_set(f); sc.render.filepath = os.path.join(out, f'f{f:04d}.png')
    t = time.time(); bpy.ops.render.render(write_still=True); times.append(time.time() - t)
    print(f'kare {f}  {times[-1]:.2f} sn', flush=True)
try:
    import gpu
    gpu_name = gpu.platform.renderer_get()
except Exception as ex:
    gpu_name = f'bilinmiyor ({ex})'
steady = times[1:] or times
per = sum(steady) / len(steady)
rep = [
    '', f'EEVEE TEST {sc.render.resolution_x}x{sc.render.resolution_y} | GPU: {gpu_name} | Blender {bpy.app.version_string}',
    f'Kareler {f0}-{f1} ({len(times)} kare)',
    f'Ilk kare (shader derleme dahil, tek seferlik hazirlik): {times[0]:.1f} sn',
    f'Sonraki karelerin ortalamasi: {per:.2f} sn/kare (en hizli {min(steady):.2f}, en yavas {max(steady):.2f})',
    f'Hesap (24 fps, yalnizca render): 13 sn deneme = {per * 312 / 60:.1f} dk | 8,5 dk bolum = {per * 12240 / 3600:.2f} saat | 9 dk bolum = {per * 12960 / 3600:.2f} saat',
    'Not: Bu sure modelleme, animasyon ve sahne hazirligini KAPSAMAZ; yalnizca kare render suresidir.', '']
txt = '\n'.join(rep); print(txt)
open(os.path.join(root, 'render', f'{name}_sonuc.txt'), 'w', encoding='utf-8').write(txt)
