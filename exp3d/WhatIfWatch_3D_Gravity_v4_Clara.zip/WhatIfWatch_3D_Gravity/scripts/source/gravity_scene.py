# What If Watch — 3D test "Max controls gravity" (13 s, 3 shots, 1920x1080, 24 fps)
# Power rule shown: Max changes gravity ONLY for small objects he selects near him (mug, then apple).
# The book on the same table, the table and the room never float.
# Run: python gravity_scene.py <out.blend>      (bpy 5.0 module)   or   blender -b -P gravity_scene.py -- <out.blend>
import sys, os, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bpy
from mathutils import Vector, Matrix, Quaternion, Euler
argv = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else sys.argv[1:]
OUT = argv[0] if argv else os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'scene', 'gravity_test.blend')

bpy.ops.wm.read_factory_settings(use_empty=True)
import addon_utils; addon_utils.enable('cycles')
import wiw3d_lib as L
import wiw3d_chars as C

FPS, F_END = 24, 312
sc = bpy.context.scene
sc.render.fps = FPS; sc.frame_start = 1; sc.frame_end = F_END

# ============================================================== room
room = bpy.data.collections.new('Room'); sc.collection.children.link(room)

def wood_mat(name, c1, c2, scale=6.0, plank=True):
    m = bpy.data.materials.new(name); nt = m.node_tree; p = nt.nodes['Principled BSDF']
    tc = nt.nodes.new('ShaderNodeTexCoord')
    if plank:
        br = nt.nodes.new('ShaderNodeTexBrick')
        br.inputs['Color1'].default_value = L.hexcol(c1); br.inputs['Color2'].default_value = L.hexcol(c2)
        br.inputs['Mortar'].default_value = L.hexcol('#5a3a22'); br.inputs['Scale'].default_value = scale
        br.inputs['Mortar Size'].default_value = 0.008; br.inputs['Brick Width'].default_value = 1.6; br.inputs['Row Height'].default_value = 0.18
        br.offset = 0.37; br.squash = 1.0
        nt.links.new(tc.outputs['Object'], br.inputs['Vector'])
        col = br.outputs['Color']
    else:
        col = None
    wv = nt.nodes.new('ShaderNodeTexWave'); wv.inputs['Scale'].default_value = 3.0; wv.inputs['Distortion'].default_value = 6.0
    wv.inputs['Detail'].default_value = 3.0; wv.bands_direction = 'X'
    nt.links.new(tc.outputs['Object'], wv.inputs['Vector'])
    mix = nt.nodes.new('ShaderNodeMix'); mix.data_type = 'RGBA'; mix.blend_type = 'MULTIPLY'
    mix.inputs['Factor'].default_value = 0.18
    if col is not None:
        nt.links.new(col, mix.inputs['A'])
    else:
        mix.inputs['A'].default_value = L.hexcol(c1)
    nt.links.new(wv.outputs['Color'], mix.inputs['B'])
    nt.links.new(mix.outputs['Result'], p.inputs['Base Color'])
    p.inputs['Roughness'].default_value = 0.45; p.inputs['Coat Weight'].default_value = 0.15
    m.diffuse_color = L.hexcol(c1)
    return m

floor_m = wood_mat('floor', '#B98556', '#A7744A', scale=1.6)
fl = L.rbox('floor', (0, 0, -0.06), (9, 9, 0.1), floor_m, room, bevel=0.02, subsurf=0)
fl.location.z = -0.012 - 0.05 + 0.06 - 0.06   # floor top at z = -0.012 (rug top at 0)
wall_m = L.mat('wall', '#F3E3C8', rough=0.85, spec=0.3)
wain_m = L.mat('wainscot', '#86A897', rough=0.6, coat=0.1)
trim_m = L.mat('trim', '#FBF4E6', rough=0.5)
WALL_Y = 1.7
L.rbox('wall_back', (0, WALL_Y + 0.05, 1.5), (9, 0.1, 3.2), wall_m, room, bevel=0.01, subsurf=0)
L.rbox('wall_left', (-3.0, 0, 1.5), (0.1, 9, 3.2), wall_m, room, bevel=0.01, subsurf=0)
L.rbox('wainscot', (0, WALL_Y - 0.005, 0.45), (9, 0.03, 0.9), wain_m, room, bevel=0.05, subsurf=0)
L.rbox('chair_rail', (0, WALL_Y - 0.025, 0.91), (9, 0.05, 0.04), trim_m, room, bevel=0.3, subsurf=1)
L.rbox('baseboard', (0, WALL_Y - 0.025, 0.05), (9, 0.05, 0.1), trim_m, room, bevel=0.2, subsurf=1)
for i, x in enumerate([-2.4 + 0.45 * k for k in range(12)]):
    L.rbox(f'panel{i}', (x, WALL_Y - 0.022, 0.48), (0.36, 0.012, 0.66), L.mat('wainscot_dk', '#779A89', rough=0.6), room, bevel=0.15, subsurf=1)
# window (left part of back wall), glowing warm evening sky
WX = -1.35
glass = L.mat('sky', '#FFD9A6', emit='#FFD9A6', emit_str=2.2, rough=1.0)
L.rbox('window_sky', (WX, WALL_Y + 0.0, 1.55), (1.1, 0.02, 1.15), glass, room, bevel=0.02, subsurf=0)
for nm, c, s in (('wf_top', (WX, WALL_Y - 0.03, 2.15), (1.24, 0.08, 0.07)), ('wf_bot', (WX, WALL_Y - 0.06, 0.95), (1.34, 0.14, 0.06)),
                 ('wf_l', (WX - 0.59, WALL_Y - 0.03, 1.55), (0.07, 0.08, 1.22)), ('wf_r', (WX + 0.59, WALL_Y - 0.03, 1.55), (0.07, 0.08, 1.22)),
                 ('wf_mv', (WX, WALL_Y - 0.03, 1.55), (0.035, 0.05, 1.16)), ('wf_mh', (WX, WALL_Y - 0.03, 1.6), (1.16, 0.05, 0.035))):
    L.rbox(nm, c, s, trim_m, room, bevel=0.3, subsurf=1)
# shelf with books (right part of back wall)
shelf_m = wood_mat('shelfwood', '#8E5B34', '#8E5B34', plank=False)
L.rbox('shelf', (1.15, WALL_Y - 0.13, 1.42), (1.1, 0.24, 0.04), shelf_m, room, bevel=0.3)
book_cols = ['#E63946', '#36C2B4', '#FFC93C', '#5E6BC4', '#F28C4B', '#7BC043', '#E85D8C']
x = 0.68
for i, c in enumerate(book_cols):
    h = 0.2 + 0.05 * math.sin(i * 2.1); w = 0.045 + 0.012 * math.cos(i * 1.3)
    L.rbox(f'shelfbook{i}', (x + w / 2, WALL_Y - 0.14, 1.44 + h / 2), (w, 0.17, h), L.mat(f'book{i}', c, rough=0.5), room, bevel=0.2)
    x += w + 0.006
pot = L.lathe('plantpot', [(0, 1.44), (0.06, 1.44), (0.075, 1.56), (0.08, 1.57), (0, 1.57)], L.mat('pot', '#D9774A', rough=0.6), room, seg=20,
              mtx=Matrix.Translation((1.5, WALL_Y - 0.14, 0)))
leaf_m = L.mat('leaf', '#5DA35A', rough=0.5, sheen=0.3)
for k in range(7):
    a = k * 2.4; r = 0.08 + 0.03 * math.sin(k)
    L.tube(f'leaf{k}', [(1.5, WALL_Y - 0.14, 1.55), (1.5 + math.cos(a) * r * 0.6, WALL_Y - 0.14 + math.sin(a) * r * 0.6, 1.66), (1.5 + math.cos(a) * r, WALL_Y - 0.14 + math.sin(a) * r, 1.72 + 0.02 * k % 3)],
           [0.012, 0.022, 0.004], leaf_m, room, seg=8, flat=0.35)
# floor lamp (right)
LX, LY = 1.55, 0.95
metal = L.mat('lampmetal', '#3B3A45', rough=0.35, metal=0.7)
L.lathe('lamp_base', [(0, 0), (0.17, 0), (0.17, 0.02), (0.05, 0.04), (0, 0.04)], metal, room, seg=24, mtx=Matrix.Translation((LX, LY, -0.012)))
L.tube('lamp_pole', [(LX, LY, 0.03), (LX, LY, 1.35)], 0.014, metal, room, seg=10, subsurf=0)
shade_m = L.mat('lampshade', '#FFE7C2', emit='#FFC98A', emit_str=3.0, rough=0.8)
L.lathe('lamp_shade', [(0.0, 1.33), (0.2, 1.33), (0.13, 1.58), (0.0, 1.58)], shade_m, room, seg=28, mtx=Matrix.Translation((LX, LY, 0)), subsurf=0)
# rug (Max and the table stand on it: rug top = z 0)
L.rbox('rug', (-0.15, -0.05, -0.006), (2.4, 1.6, 0.012), L.mat('rug', '#C8644B', rough=0.95, sheen=0.6), room, bevel=0.45, subsurf=1)
L.rbox('rug_inner', (-0.15, -0.05, -0.0045), (2.15, 1.35, 0.01), L.mat('rug_in', '#E0835E', rough=0.95, sheen=0.6), room, bevel=0.45, subsurf=1)

# ============================================================== side table + objects
TX, TY = -0.72, -0.02          # table centre (Max's right / screen left)
TOP = 0.62                     # table top surface height
tw = wood_mat('tablewood', '#B07A4A', '#A06B3E', plank=False)
L.rbox('table_top', (TX, TY, TOP - 0.02), (0.62, 0.46, 0.04), tw, room, bevel=0.35)
L.rbox('table_apron', (TX, TY, TOP - 0.07), (0.54, 0.38, 0.07), tw, room, bevel=0.2)
for i, (dx, dy) in enumerate(((-0.25, -0.17), (0.25, -0.17), (-0.25, 0.17), (0.25, 0.17))):
    L.lathe(f'table_leg{i}', [(0, 0), (0.018, 0), (0.024, 0.3), (0.026, TOP - 0.1), (0, TOP - 0.1)], tw, room, seg=12,
            mtx=Matrix.Translation((TX + dx, TY + dy, 0)), subsurf=0)
props = bpy.data.collections.new('Props'); sc.collection.children.link(props)
# mug (selected object #1)
MUG0 = Vector((-0.55, -0.11, TOP))
mug_m = L.mat('mug', '#F26B4F', rough=0.18, coat=0.6)
mug = L.lathe('mug', [(0, 0.0), (0.04, 0.0), (0.045, 0.006), (0.046, 0.095), (0.042, 0.097), (0.04, 0.012), (0, 0.012)], mug_m, props, seg=28)
mh = L.torus('mug_handle', (0.046, 0, 0.05), 0.026, 0.008, mug_m, props,
             rot=Quaternion((0, 1, 0), math.radians(90)) @ Quaternion((1, 0, 0), math.radians(90)), arc=math.pi, seg=16)
band = L.torus('mug_band', (0, 0, 0.07), 0.0462, 0.004, L.mat('mugband', '#FFF4E0', rough=0.25, coat=0.5), props, flat=1.5)
coffee = L.lathe('mug_coffee', [(0, 0.08), (0.041, 0.08), (0, 0.0805)], L.mat('cocoa', '#6B3E26', rough=0.15), props, seg=20, subsurf=0)
mug_root = bpy.data.objects.new('MUG', None); props.objects.link(mug_root); mug_root.empty_display_size = 0.06
for o in (mug, mh, band, coffee):
    L.parent_obj(o, mug_root)
mug_root.location = MUG0; mug_root.rotation_euler = (0, 0, math.radians(200))
# apple (selected object #2 — lifts by accident)
APP0 = Vector((-0.82, -0.07, TOP - 0.0017))   # lathe+subdiv bottom sits 1.7 mm high: measured
ap_m = L.mat('apple', '#7BC043', rough=0.3, coat=0.4)
apple = L.lathe('apple', [(0, 0.004), (0.022, 0.0), (0.038, 0.012), (0.044, 0.035), (0.041, 0.06), (0.03, 0.074), (0.012, 0.07), (0, 0.062)], ap_m, props, seg=24)
stem = L.tube('apple_stem', [(0, 0, 0.06), (0.002, 0, 0.085), (0.008, 0, 0.095)], 0.0035, L.mat('stem', '#5a3a22'), props, seg=6)
leaf = L.tube('apple_leaf', [(0.004, 0, 0.085), (0.02, 0.006, 0.095), (0.04, 0.008, 0.094)], [0.002, 0.009, 0.001], L.mat('leaf', '#5DA35A'), props, seg=8, flat=0.25, up=(0, 0, 1))
app_root = bpy.data.objects.new('APPLE', None); props.objects.link(app_root); app_root.empty_display_size = 0.05
for o in (apple, stem, leaf):
    L.parent_obj(o, app_root)
app_root.location = APP0
# books: NOT selected — they must stay on the table the whole time
L.rbox('table_book1', (-0.78, 0.12, TOP + 0.016), (0.2, 0.14, 0.032), L.mat('book2', '#5E6BC4', rough=0.5), room, bevel=0.15,
       rot=Quaternion((0, 0, 1), math.radians(8)))
L.rbox('table_book2', (-0.77, 0.115, TOP + 0.045), (0.17, 0.12, 0.026), L.mat('book0', '#E63946', rough=0.5), room, bevel=0.15,
       rot=Quaternion((0, 0, 1), math.radians(-6)))

# gravity effect: thin glowing ring under each lifted object + glow in Max's raised palm (each with its own material)
def fx_mat(name):
    return L.mat(name, '#9EF0FF', emit='#7FE6F2', emit_str=0.0, rough=0.3, alpha=1.0)
ring_mug = L.torus('fx_ring_mug', (0, 0, -0.006), 0.062, 0.0035, fx_mat('fx_mug'), props, subsurf=0)
ring_app = L.torus('fx_ring_apple', (0, 0, -0.006), 0.056, 0.0035, fx_mat('fx_apple'), props, subsurf=0)
L.parent_obj(ring_mug, mug_root); L.parent_obj(ring_app, app_root)
ring_mug.matrix_parent_inverse = Matrix.Identity(4); ring_mug.location = (0, 0, -0.006)
ring_app.matrix_parent_inverse = Matrix.Identity(4); ring_app.location = (0, 0, -0.006)

# ============================================================== Max
MAX_YAW = -32.0
mx = C.build('M', 'Max', location=(0, 0, 0), yaw_deg=MAX_YAW)
rig, ctrl = mx['rig'], mx['ctrl']
palm_glow = L.ellipsoid('fx_palm', (0, 0, 0), (0.016, 0.005, 0.016), fx_mat('fx_palm'), props, subsurf=0)
palm_glow.parent = rig; palm_glow.parent_type = 'BONE'; palm_glow.parent_bone = 'hand.R'
palm_glow.matrix_parent_inverse = Matrix.Identity(4)
palm_glow.location = (0.03, -0.045, 0.0)   # bone space: in front of the right palm (checked on the draft)

# ============================================================== lights + world
def area(name, loc, target, power, size, color, coll=room):
    ld = bpy.data.lights.new(name, 'AREA'); ld.energy = power; ld.size = size; ld.color = L.hexcol(color)[:3]
    ob = bpy.data.objects.new(name, ld); coll.objects.link(ob); ob.location = loc
    ob.rotation_euler = (Vector(target) - Vector(loc)).to_track_quat('-Z', 'Y').to_euler()
    return ob
area('L_window', (WX + 0.1, WALL_Y - 0.25, 1.6), (-0.3, -0.6, 0.6), 260, 1.2, '#FFD29A')
area('L_key', (-1.7, -2.1, 2.5), (-0.2, 0, 0.75), 230, 1.6, '#FFE1BE')
area('L_fill', (1.9, -2.2, 1.4), (-0.2, 0, 0.8), 70, 2.4, '#DCE6FF')
area('L_rim', (1.3, 1.25, 2.1), (-0.1, 0, 0.9), 110, 1.0, '#FFE6C8')
pl = bpy.data.lights.new('L_lamp', 'POINT'); pl.energy = 35; pl.color = L.hexcol('#FFB46B')[:3]; pl.shadow_soft_size = 0.12
plo = bpy.data.objects.new('L_lamp', pl); room.objects.link(plo); plo.location = (LX, LY, 1.45)
w = bpy.data.worlds.new('world'); sc.world = w
w.node_tree.nodes['Background'].inputs['Color'].default_value = L.hexcol('#4a3a30')
w.node_tree.nodes['Background'].inputs['Strength'].default_value = 0.25

# ============================================================== animation helpers
RW = rig.matrix_world.copy(); RWi = RW.inverted(); RQ = RW.to_quaternion()
def to_arm(p):
    return RWi @ Vector(p)
def pb(n):
    return rig.pose.bones[n]
def rest_q(b):
    return rig.data.bones[b].matrix_local.to_quaternion()
def key_bone(name, frame, loc_arm=None, rot_arm=None, rest_relative=True):
    """loc_arm: armature-space position of the bone head (absolute) ; rot_arm: armature-space delta rotation."""
    p = pb(name); B = rest_q(name)
    if loc_arm is not None:
        head0 = rig.data.bones[name].head_local
        p.location = B.inverted() @ (Vector(loc_arm) - head0)
        p.keyframe_insert('location', frame=frame)
    if rot_arm is not None:
        p.rotation_quaternion = B.inverted() @ rot_arm @ B
        p.keyframe_insert('rotation_quaternion', frame=frame)
def eul(x=0, y=0, z=0):
    return Euler((math.radians(x), math.radians(y), math.radians(z)), 'XYZ').to_quaternion()
def basis_q(palm, finger):
    palm = palm.normalized(); finger = (finger - palm * finger.dot(palm)).normalized()
    return Matrix((palm, finger, palm.cross(finger))).transposed()
def hand_rot(side, palm_dir_arm, finger_dir_arm):
    """Delta rotation taking the rest hand (palm toward the body, fingers down) to the wanted directions."""
    rest = basis_q(Vector((1 if side == 'R' else -1, 0, 0)), Vector((0, 0, -1)))
    want = basis_q(palm_dir_arm, finger_dir_arm)
    return (want @ rest.inverted()).to_quaternion()
def upd():
    bpy.context.view_layer.update()

# ---------------------------------------------------------------- timeline (frames)
# shot 1: 1-108  raise hand, mug lifts      shot 2: 109-204  surprise, reach, apple lifts
# shot 3: 205-312 step back, lower hand, both objects land
PEL = rig.data.bones['pelvis'].head_local.copy()
pel_keys = [  # frame, offset (armature space: x=Max's left, y=back, z=up), rotation
    (1, (0, 0, -0.012), eul()), (40, (0, 0, -0.012), eul()),
    (110, (0, 0.018, -0.006), eul(x=-3)),                     # surprise: pulls back a little
    (128, (0, 0.012, -0.012), eul()),
    (150, (-0.045, -0.02, -0.03), eul(y=-4, z=-6)),           # weight onto the right leg, toward the table
    (176, (-0.045, -0.02, -0.03), eul(y=-4, z=-6)),
    (205, (-0.03, 0.0, -0.022), eul(z=-3)),
    (214, (0.0, 0.04, -0.035), eul(z=4)),                     # step back: weight between the feet
    (230, (0.025, 0.075, -0.028), eul(z=6)),                  # weight onto the stepped-back left leg
    (290, (0.02, 0.07, -0.022), eul(z=4)),
    (312, (0.02, 0.07, -0.018), eul(z=4)),
]
spine_keys = [
    (1, eul()), (36, eul(z=-4)), (90, eul(z=-6)),
    (110, eul(x=-5, z=-6)),                                   # surprise: chest back
    (150, eul(x=7, y=-5, z=-13)), (176, eul(x=7, y=-5, z=-13)),   # lean + twist toward the mug (left-hand reach)
    (190, eul(x=4, y=-3, z=-18)),
    (214, eul(x=-6, z=-8)), (240, eul(x=-4, z=-6)),
    (290, eul(x=-2, z=-4)), (300, eul(x=2, z=-3)), (312, eul(x=1, z=-3)),
]
head_keys = [
    (1, eul(x=4)), (24, eul(x=10, z=-12)), (60, eul(x=6, z=-10)), (100, eul(x=-4, z=-8)),
    (112, eul(x=-10, z=-6)), (150, eul(x=6, z=-10)), (164, eul(x=10, z=-26, y=4)),   # snaps toward the apple
    (200, eul(x=8, z=-22)), (226, eul(x=4, z=-18)), (290, eul(x=10, z=-16)), (312, eul(x=6, z=-8)),
]
for f, off, r in pel_keys:
    key_bone('pelvis', f, loc_arm=PEL + Vector(off), rot_arm=r)
for f, r in spine_keys:
    key_bone('spine', f, rot_arm=r)
for f, r in head_keys:
    key_bone('head', f, rot_arm=r)

# feet: right foot planted for the whole shot; left foot steps back (lift 207-224, planted from 228)
for s in ('L', 'R'):
    h0 = rig.data.bones[f'foot_ik.{s}'].head_local.copy()
    key_bone(f'foot_ik.{s}', 1, loc_arm=h0, rot_arm=eul())
FL = rig.data.bones['foot_ik.L'].head_local.copy()
STEP = Vector((0.06, 0.17, 0))
for f, off, r in ((206, (0, 0, 0), eul()), (212, (0.005, 0.03, 0.05), eul(x=-14)), (220, (0.04, 0.12, 0.055), eul(x=-6, z=10)),
                  (227, (STEP.x, STEP.y, 0.0), eul(z=12)), (312, (STEP.x, STEP.y, 0.0), eul(z=12))):
    key_bone('foot_ik.L', f, loc_arm=FL + Vector(off), rot_arm=r)
FR = rig.data.bones['foot_ik.R'].head_local.copy()
key_bone('foot_ik.R', 312, loc_arm=FR, rot_arm=eul())

# objects (world space)
def key_obj(ob, f, loc, rot=(0, 0, 0)):
    ob.location = loc; ob.rotation_euler = Euler([math.radians(a) for a in rot]); ob.keyframe_insert('location', frame=f); ob.keyframe_insert('rotation_euler', frame=f)
MUGR = 200
mug_keys = [(1, MUG0, (0, 0, MUGR)), (40, MUG0, (0, 0, MUGR)), (64, MUG0 + Vector((0, 0, 0.05)), (3, -2, MUGR + 8)),
            (104, MUG0 + Vector((0.0, 0.0, 0.14)), (6, -4, MUGR + 25)), (140, MUG0 + Vector((-0.01, 0, 0.155)), (4, 3, MUGR + 35)),
            (160, MUG0 + Vector((-0.05, 0.02, 0.165)), (-5, 5, MUGR + 48)),                    # drifts just out of reach
            (200, MUG0 + Vector((-0.05, 0.01, 0.16)), (-3, 2, MUGR + 60)), (240, MUG0 + Vector((-0.04, 0.0, 0.155)), (2, -2, MUGR + 70)),
            (270, MUG0 + Vector((-0.02, 0, 0.075)), (3, 1, MUGR + 78)), (286, MUG0 + Vector((0, 0, 0.012)), (0.5, 0, MUGR + 82)),
            (290, MUG0 + Vector((0, 0, -0.0)), (0, 0, MUGR + 82)), (294, MUG0 + Vector((0, 0, 0.003)), (0, 0, MUGR + 82)),
            (298, MUG0, (0, 0, MUGR + 82)), (312, MUG0, (0, 0, MUGR + 82))]
app_keys = [(1, APP0, (0, 0, 0)), (150, APP0, (0, 0, 0)), (170, APP0 + Vector((0, 0, 0.045)), (8, 4, 15)),
            (204, APP0 + Vector((0.01, 0, 0.12)), (14, 6, 40)), (240, APP0 + Vector((0.01, 0, 0.125)), (10, -4, 60)),
            (274, APP0 + Vector((0.005, 0, 0.05)), (4, 0, 70)), (290, APP0 + Vector((0, 0, 0.008)), (0, 0, 75)),
            (294, APP0, (0, 0, 75)), (297, APP0 + Vector((0, 0, 0.002)), (0, 0, 75)), (300, APP0, (0, 0, 75)), (312, APP0, (0, 0, 75))]
for f, p, r in mug_keys:
    key_obj(mug_root, f, p, r)
for f, p, r in app_keys:
    key_obj(app_root, f, p, r)
L.set_interp(mug_root, 'BEZIER'); L.set_interp(app_root, 'BEZIER')

# hands (world-space targets, then converted; distance clamped to the reachable arm length)
ARM_LEN = (rig.data.bones['upper_arm.R'].length + rig.data.bones['forearm.R'].length) * 0.975
def key_hand(side, f, wrist_world, palm_w, finger_w):
    sc.frame_set(f); upd()
    sh_w = rig.matrix_world @ pb(f'upper_arm.{side}').head
    wv = Vector(wrist_world) - sh_w
    if wv.length > ARM_LEN:
        wv = wv.normalized() * ARM_LEN
    wa = to_arm(sh_w + wv)
    q = hand_rot(side, RQ.inverted() @ Vector(palm_w), RQ.inverted() @ Vector(finger_w))
    key_bone(f'hand_ik.{side}', f, loc_arm=wa, rot_arm=q)

def mug_at(f):
    sc.frame_set(f); upd(); return mug_root.matrix_world.to_translation() + Vector((0, 0, 0.05))
def app_at(f):
    sc.frame_set(f); upd(); return app_root.matrix_world.to_translation() + Vector((0, 0, 0.04))
REST = {s: rig.matrix_world @ rig.data.bones[f'hand_ik.{s}'].head_local for s in 'LR'}
DOWN = Vector((0, 0, -1))
# right hand: raise (control), hold, lower slowly
key_hand('R', 1, REST['R'], RQ @ Vector((1, 0, 0)), DOWN)
key_hand('R', 14, REST['R'] + Vector((0, 0, 0.01)), RQ @ Vector((1, 0, 0)), DOWN)
# lift in front of the body first (clears the table edge), then turn the palm toward the mug
key_hand('R', 20, rig.matrix_world @ Vector((-0.3, -0.12, 0.66)), RQ @ Vector((0.8, -0.3, 0.2)), RQ @ Vector((-0.2, -0.4, -0.6)))
key_hand('R', 26, rig.matrix_world @ Vector((-0.2, -0.3, 0.72)), RQ @ Vector((0.6, -0.5, 0.3)), Vector((0, 0, 1)))
for f in (38, 70, 104, 140, 176, 205, 240):
    m = mug_at(f)
    sh = rig.matrix_world @ pb('upper_arm.R').head
    if f in (140, 176, 205):   # while reaching with the other hand: keep the control hand out to the side, away from the face
        wr = sh + RQ @ Vector((-0.27, -0.06, 0.0))
    else:
        wr = sh + (m - sh) * 0.42 + Vector((0, 0, -0.01))   # v2: hand kept further from the mug (read as grabbing in shot B)
    key_hand('R', f, wr, (m - wr), Vector((0, 0, 1)) + (m - wr).normalized() * 0.4)
key_hand('R', 280, rig.matrix_world @ Vector((-0.22, -0.3, 0.7)), RQ @ Vector((0.6, -0.5, -0.3)), RQ @ Vector((-0.2, -0.3, -0.6)))
for f, k in ((264, 0.75),):
    m = mug_at(f); sh = rig.matrix_world @ pb('upper_arm.R').head
    wr = (sh + (m - sh) * 0.6).lerp(REST['R'] + Vector((-0.03, -0.04, 0.02)), 1 - k)
    key_hand('R', f, wr, (m - wr).lerp(RQ @ Vector((1, 0, 0)), 1 - k), Vector((0, 0, 1)).lerp(DOWN, 1 - k) + (m - wr).normalized() * 0.3 * k)
key_hand('R', 312, REST['R'] + Vector((0, 0, 0.005)), RQ @ Vector((1, 0, 0)), DOWN)
# left hand: rest, reach toward the mug (stops short), pull back to the chest during the step, relax
key_hand('L', 1, REST['L'], RQ @ Vector((-1, 0, 0)), DOWN)
key_hand('L', 118, REST['L'] + Vector((0, 0, 0.01)), RQ @ Vector((-1, 0, 0)), DOWN)
key_hand('L', 134, rig.matrix_world @ Vector((0.17, -0.36, 0.6)), RQ @ Vector((-0.6, 0, -0.8)), RQ @ Vector((-0.3, -0.9, 0.1)))
for f in (150, 176):
    m = mug_at(f)
    key_hand('L', f, m + (rig.matrix_world @ pb('upper_arm.L').head - m).normalized() * 0.19 + Vector((0, 0, -0.03)), Vector((0, 0, -1)) + (m - REST['L']).normalized() * 0.3, (m - REST['L']).normalized())
chest = rig.matrix_world @ Vector((0.1, -0.34, 0.72))
key_hand('L', 192, (rig.matrix_world @ pb('upper_arm.L').head).lerp(mug_at(192), 0.45), Vector((0, 0, -1)), (mug_at(192) - REST['L']).normalized())
key_hand('L', 207, rig.matrix_world @ Vector((0.17, -0.42, 0.7)), Vector((0, 0, -1)), RQ @ Vector((-0.2, -0.9, 0.2)))
key_hand('L', 222, chest, RQ @ Vector((0, -1, 0)), Vector((0, 0, 1)))
key_hand('L', 286, chest + RQ @ Vector((0.02, 0.0, -0.03)), RQ @ Vector((0, -1, 0)), Vector((0, 0, 1)))
key_hand('L', 299, rig.matrix_world @ Vector((0.34, -0.16, 0.55)), RQ @ Vector((-0.8, -0.3, 0.2)), RQ @ Vector((0.2, -0.4, -0.6)))
key_hand('L', 312, REST['L'] + Vector((0, 0, 0.01)), RQ @ Vector((-1, 0, 0)), DOWN)
L.set_interp(rig, 'BEZIER')

# face: gaze (eyes aim at a world point), blinks, brows, mouth
def key_gaze(f, target):
    sc.frame_set(f); upd()
    for s in 'LR':
        e = ctrl[f'eye.{s}']
        if 'rest_q' not in e:
            e['rest_q'] = list(e.rotation_quaternion)
        cur = e.rotation_quaternion.copy()
        e.rotation_quaternion = Quaternion(e['rest_q']); upd()
        pos = e.matrix_world.to_translation(); scl = e.matrix_world.to_scale()
        d0 = (e.matrix_world.to_quaternion() @ Vector((0, -1, 0))).normalized()
        e.rotation_quaternion = cur
        d = (Vector(target) - pos).normalized()
        ang = d0.angle(d)
        MAXA = math.radians(24)          # keep the iris inside the eye white (measured on the 12-sample test frame)
        if ang > MAXA:
            d = Quaternion().slerp(d0.rotation_difference(d), MAXA / ang) @ d0
        e.matrix_world = Matrix.Translation(pos) @ L.look_rot(d).to_matrix().to_4x4() @ Matrix.Diagonal((scl.x, scl.y, scl.z, 1))
        e.keyframe_insert('rotation_quaternion', frame=f); e.keyframe_insert('location', frame=f)
CAM_A_POS = Vector((0.45, -2.75, 1.08))
for f, t in ((1, CAM_A_POS), (20, MUG0 + Vector((0, 0, 0.05))), (60, None), (104, None), (118, None), (150, None), (160, 'apple'), (200, 'apple'),
             (214, 'between'), (250, None), (288, None), (300, CAM_A_POS), (312, CAM_A_POS)):
    if t is None:
        t = mug_at(f)
    elif t == 'apple':
        t = app_at(f)
    elif t == 'between':
        t = mug_at(f).lerp(app_at(f), 0.5)
    key_gaze(f, t)
def key_blink(f0):
    for s in 'LR':
        e = ctrl[f'eye.{s}']
        for df, z in ((0, 1.0), (2, 0.12), (4, 0.12), (6, 1.0)):
            e.scale = (1, 1, z); e.keyframe_insert('scale', frame=f0 + df)
for f in (10, 120, 206, 302):
    key_blink(f)
def key_brows(f, up, inner):
    for s, x in (('L', 1), ('R', -1)):
        b = ctrl[f'brow.{s}']
        if not b.get('rest'):
            b['rest'] = list(b.location)
        r = Vector(b['rest'])
        b.location = r + Vector((0, 0, up)); b.rotation_euler = (0, math.radians(-inner * x), 0)
        b.keyframe_insert('location', frame=f); b.keyframe_insert('rotation_euler', frame=f)
for f, up, inner in ((1, 0, 0), (30, -0.004, -4), (80, 0.008, 0), (108, 0.02, 4), (150, 0.012, 2), (162, 0.022, 14), (210, 0.014, 12),
                     (280, 0.006, 6), (300, 0.0, 0), (312, 0.0, 0)):
    key_brows(f, up, inner)
for f, m in ((1, 'smile'), (30, 'flat'), (84, 'O'), (150, 'flat'), (162, 'O'), (214, 'flat'), (296, 'smile')):
    C.show_mouth(ctrl, m, f)
for e in [ctrl['eye.L'], ctrl['eye.R'], ctrl['brow.L'], ctrl['brow.R']]:
    L.set_interp(e, 'BEZIER')

# ============================================================== Clara (v3): watches, is surprised when the mug lifts, points at the apple
CL_POS = Vector((1.0, 0.3, 0.0)); CL_YAW = -52.0
cl = C.build('C', 'Clara', location=CL_POS, yaw_deg=CL_YAW)
def use_rig(r, c):
    """Point the shared key helpers (key_bone, key_hand, key_gaze, ...) at another character."""
    global rig, RW, RWi, RQ, ctrl, ARM_LEN, REST
    rig, ctrl = r, c
    upd(); RW = rig.matrix_world.copy(); RWi = RW.inverted(); RQ = RW.to_quaternion()
    ARM_LEN = (rig.data.bones['upper_arm.R'].length + rig.data.bones['forearm.R'].length) * 0.975
    REST = {s: rig.matrix_world @ rig.data.bones[f'hand_ik.{s}'].head_local for s in 'LR'}
max_rig, max_ctrl = rig, ctrl
use_rig(cl['rig'], cl['ctrl'])
CPEL = rig.data.bones['pelvis'].head_local.copy()
def look_q(target, maxyaw=50, maxpitch=25, f=None):
    """Head rotation (armature-space delta) that turns Clara's face toward a world point (clamped)."""
    if f is not None:
        sc.frame_set(f); upd()
    head = rig.matrix_world @ rig.data.bones['head'].head_local + RQ @ Vector((0, 0, 0.23))
    d = RQ.inverted() @ (Vector(target) - head)
    yaw = max(-maxyaw, min(maxyaw, math.degrees(math.atan2(d.x, -d.y))))
    pitch = max(-maxpitch, min(maxpitch, -math.degrees(math.atan2(d.z, math.hypot(d.x, d.y)))))
    return eul(x=pitch * 0.8, z=yaw * 0.7)        # the rest of the turn is done by the eyes
MAXHEAD = lambda f: max_rig.matrix_world @ max_rig.pose.bones['head'].head + Vector((0, 0, 0.2))
for f, off, r in ((1, (0, 0, -0.012), eul()), (52, (0, 0, -0.012), eul()), (62, (0, 0.025, -0.016), eul(x=-4)),
                  (100, (0, 0.01, -0.012), eul()), (172, (-0.015, 0, -0.016), eul(z=-4)), (232, (0, 0, -0.012), eul()), (312, (0, 0, -0.012), eul())):
    key_bone('pelvis', f, loc_arm=CPEL + Vector(off), rot_arm=r)
for f, r in ((1, eul()), (52, eul()), (62, eul(x=-7)), (100, eul(x=-2)), (172, eul(x=4, z=-8)), (232, eul(x=1)), (312, eul())):
    key_bone('spine', f, rot_arm=r)
for s in ('L', 'R'):
    key_bone(f'foot_ik.{s}', 1, loc_arm=rig.data.bones[f'foot_ik.{s}'].head_local.copy(), rot_arm=eul())
for f, t in ((1, 'max'), (44, 'mug'), (110, 'max'), (158, 'apple'), (205, 'apple'), (230, 'max'), (290, 'mug'), (312, 'max')):
    tgt = MAXHEAD(f) if t == 'max' else (mug_at(f) if t == 'mug' else app_at(f))
    key_bone('head', f, rot_arm=look_q(tgt, f=f))
    key_gaze(f, tgt)
# hands: rest -> both hands up near the chin (surprise) -> relaxed -> right hand points at the apple ("the apple too!") -> rest
key_hand('R', 1, REST['R'], RQ @ Vector((1, 0, 0)), DOWN); key_hand('L', 1, REST['L'], RQ @ Vector((-1, 0, 0)), DOWN)
key_hand('R', 52, REST['R'], RQ @ Vector((1, 0, 0)), DOWN); key_hand('L', 52, REST['L'], RQ @ Vector((-1, 0, 0)), DOWN)
for f in (58, 108):   # pass in front of the coat, not through it
    key_hand('R', f, rig.matrix_world @ Vector((-0.3, -0.3, 0.6)), RQ @ Vector((0.6, -0.8, 0)), RQ @ Vector((0.2, -0.3, 0.6)))
    key_hand('L', f, rig.matrix_world @ Vector((0.3, -0.3, 0.6)), RQ @ Vector((-0.6, -0.8, 0)), RQ @ Vector((-0.2, -0.3, 0.6)))
key_hand('R', 64, rig.matrix_world @ Vector((-0.12, -0.33, 0.8)), RQ @ Vector((0.2, -1, 0)), RQ @ Vector((0.1, 0, 1)))
key_hand('L', 64, rig.matrix_world @ Vector((0.12, -0.33, 0.8)), RQ @ Vector((-0.2, -1, 0)), RQ @ Vector((-0.1, 0, 1)))
key_hand('R', 92, rig.matrix_world @ Vector((-0.13, -0.32, 0.76)), RQ @ Vector((0.2, -1, 0)), RQ @ Vector((0.1, 0, 1)))
key_hand('L', 92, rig.matrix_world @ Vector((0.13, -0.32, 0.76)), RQ @ Vector((-0.2, -1, 0)), RQ @ Vector((-0.1, 0, 1)))
key_hand('R', 116, REST['R'] + Vector((0, 0, 0.01)), RQ @ Vector((1, 0, 0)), DOWN); key_hand('L', 116, REST['L'] + Vector((0, 0, 0.01)), RQ @ Vector((-1, 0, 0)), DOWN)
for f in (170, 198):   # points at the apple as it starts to float (visible behind Max in shot B)
    a = app_at(f); sh = rig.matrix_world @ pb('upper_arm.R').head
    key_hand('R', f, sh + (a - sh).normalized() * 0.33, Vector((0, 0, -1)), (a - sh).normalized())
key_hand('R', 140, REST['R'] + RQ @ Vector((-0.05, -0.03, 0.02)), RQ @ Vector((1, 0, 0)), DOWN)   # clear of the coat while the torso turns
key_hand('R', 160, REST['R'] + RQ @ Vector((-0.06, -0.05, 0.04)), RQ @ Vector((1, 0, 0)), DOWN)
key_hand('R', 232, REST['R'] + Vector((0, 0, 0.01)), RQ @ Vector((1, 0, 0)), DOWN)
key_hand('R', 312, REST['R'], RQ @ Vector((1, 0, 0)), DOWN); key_hand('L', 312, REST['L'], RQ @ Vector((-1, 0, 0)), DOWN)
L.set_interp(rig, 'BEZIER')
for f in (30, 140, 252):
    key_blink(f)
for f, up, inner in ((1, 0, 0), (52, 0, 0), (60, 0.022, 4), (100, 0.008, 0), (160, 0.018, 2), (210, 0.004, -3), (300, 0, 0), (312, 0, 0)):
    key_brows(f, up, inner)
for f, m in ((1, 'smile'), (56, 'O'), (104, 'smile'), (162, 'O'), (204, 'smile')):
    C.show_mouth(ctrl, m, f)
for e in [ctrl['eye.L'], ctrl['eye.R'], ctrl['brow.L'], ctrl['brow.R']]:
    L.set_interp(e, 'BEZIER')
use_rig(max_rig, max_ctrl)

# effects: ring + palm glow strength
def key_emit(matname, f, v):
    p = bpy.data.materials[matname].node_tree.nodes['Principled BSDF'].inputs['Emission Strength']
    p.default_value = v; p.keyframe_insert('default_value', frame=f)
for f, v in ((1, 0), (34, 0), (48, 4.0), (100, 3.0), (150, 3.5), (240, 3.0), (284, 2.0), (296, 0.0)):
    key_emit('fx_mug', f, v)
for f, v in ((1, 0), (150, 0), (164, 4.0), (240, 3.0), (286, 2.0), (298, 0.0)):
    key_emit('fx_apple', f, v)
for f, v in ((1, 0), (24, 0), (40, 2.5), (150, 2.5), (176, 3.0), (240, 2.5), (280, 1.2), (296, 0.0)):
    key_emit('fx_palm', f, v)
for r, fs in ((ring_mug, (34, 60, 90, 120, 150, 180, 210, 240, 270, 296)), (ring_app, (150, 176, 204, 232, 260, 298))):
    for i, f in enumerate(fs):
        s = 1.0 + 0.08 * (i % 2); r.scale = (s, s, 1); r.keyframe_insert('scale', frame=f)

# ============================================================== cameras (all on the same side: table screen-left, Max screen-right)
cams = bpy.data.collections.new('Cameras'); sc.collection.children.link(cams)
def camera(name, keys, lens, fstop=None, focus=None):
    cd = bpy.data.cameras.new(name); cd.lens = lens; cd.sensor_width = 36
    if fstop:
        cd.dof.use_dof = True; cd.dof.aperture_fstop = fstop; cd.dof.focus_distance = focus
    ob = bpy.data.objects.new(name, cd); cams.objects.link(ob)
    for f, loc, aim in keys:
        ob.location = loc; ob.rotation_euler = (Vector(aim) - Vector(loc)).to_track_quat('-Z', 'Y').to_euler()
        ob.keyframe_insert('location', frame=f); ob.keyframe_insert('rotation_euler', frame=f)
    return ob
camA = camera('CAM_A_medium_wide', [(1, CAM_A_POS + Vector((0.12, -0.2, 0)), (0.12, 0.1, 0.7)), (108, CAM_A_POS + Vector((0.08, 0.0, -0.02)), (0.1, 0.1, 0.72))], 34, 4.0, 2.9)
camB = camera('CAM_B_close', [(109, (-0.92, -1.75, 1.06), (-0.1, 0.05, 0.8)), (204, (-0.88, -1.62, 1.04), (-0.1, 0.05, 0.8))], 30, 4.0, 1.75)
camC = camera('CAM_C_wide', [(205, (-0.2, -3.1, 1.25), (-0.25, 0.1, 0.66)), (312, (-0.22, -2.75, 1.15), (-0.27, 0.1, 0.66))], 34, 5.6, 2.9)
for c in (camA, camB, camC):
    L.set_interp(c, 'BEZIER')
for f, c in ((1, camA), (109, camB), (205, camC)):
    mk = sc.timeline_markers.new(c.name, frame=f); mk.camera = c
sc.camera = camA

# ============================================================== render settings (final; drafts override)
sc.render.engine = 'CYCLES'; sc.cycles.device = 'CPU'
sc.cycles.samples = 24; sc.cycles.adaptive_threshold = 0.03; sc.cycles.use_denoising = True
sc.cycles.max_bounces = 4; sc.cycles.diffuse_bounces = 2; sc.cycles.glossy_bounces = 2; sc.cycles.transmission_bounces = 2
sc.cycles.transparent_max_bounces = 4; sc.cycles.caustics_reflective = False; sc.cycles.caustics_refractive = False
sc.render.use_persistent_data = True
sc.render.resolution_x = 1920; sc.render.resolution_y = 1080; sc.render.resolution_percentage = 100
sc.render.use_motion_blur = True; sc.render.motion_blur_shutter = 0.5
sc.view_settings.view_transform = 'Standard'; sc.view_settings.look = 'None'; sc.view_settings.exposure = -1.0
sc.render.image_settings.file_format = 'PNG'
sc.frame_set(1)
os.makedirs(os.path.dirname(os.path.abspath(OUT)), exist_ok=True)
bpy.ops.wm.save_as_mainfile(filepath=os.path.abspath(OUT))
print('saved', OUT, 'pole angles', {k: rig[k] for k in rig.keys() if k.startswith('pole')})
