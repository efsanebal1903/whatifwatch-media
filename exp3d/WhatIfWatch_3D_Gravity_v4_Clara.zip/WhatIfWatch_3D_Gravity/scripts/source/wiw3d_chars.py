# What If Watch — stylized 3D Clara & Max (procedural build, draft v0.1)
# Proportions, colours and accessories are measured from the approved 2D rig (pilot/rig.js, ref/ref_2d_front.jpg).
# Character space: facing -Y, character's left = +X, up = +Z, feet on Z=0. Height to head top ~1.30 m.
import bpy, math
from mathutils import Vector, Matrix, Quaternion, Euler
from wiw3d_lib import (mat, hexcol, tube, lathe, ellipsoid, rbox, torus, look_rot, parent_bone, parent_obj,
                       skin, smoothstep, add_outline, link)

HC = Vector((0, 0, 1.065))            # head centre
HR = Vector((0.243, 0.226, 0.229))    # head radii (slightly wide, like the 2D circle head)

PAL = {
    'skin': '#FDD6B2', 'blush': '#FF9F8E', 'white': '#FFFFFF', 'iris': '#7A4A25', 'pupil': '#1d1b2e',
    'line': '#2B1A12', 'pants': '#2B2E48', 'sole': '#2B2B38',
    'M_coat': '#FFC93C', 'M_coat_dk': '#E3A41B', 'M_boot': '#E63946', 'M_boot_dk': '#B3202C', 'M_hair': '#B97330',
    'C_coat': '#36C2B4', 'C_coat_dk': '#22998C', 'C_boot': '#F7C531', 'C_boot_dk': '#D69E12', 'C_hair': '#5B3621',
    'C_hair_dk': '#3B2214', 'C_hair_lt': '#7C4E2E', 'C_lip': '#C9485E', 'tie': '#FF6F9C',
    'copper': '#C67A3A', 'strap': '#6E4321', 'lens': '#8AE8F5', 'gold': '#F2B51C', 'gold_dk': '#C98A0C',
    'dial': '#FFF8E8', 'red': '#E63946', 'mouth_in': '#5A1C28', 'tongue': '#E46A7A', 'button': '#1d1b2e',
}

def M(key, **kw):
    base = dict(rough=0.55)
    preset = {
        'skin': dict(rough=0.5, sss=0.12, spec=0.35), 'white': dict(rough=0.18, coat=0.4),
        'iris': dict(rough=0.25, coat=0.6), 'pupil': dict(rough=0.2, coat=0.6),
        'M_coat': dict(rough=0.32, coat=0.35), 'M_coat_dk': dict(rough=0.35, coat=0.3),
        'C_coat': dict(rough=0.32, coat=0.35), 'C_coat_dk': dict(rough=0.35, coat=0.3),
        'M_boot': dict(rough=0.28, coat=0.5), 'M_boot_dk': dict(rough=0.3, coat=0.4),
        'C_boot': dict(rough=0.28, coat=0.5), 'C_boot_dk': dict(rough=0.3, coat=0.4),
        'pants': dict(rough=0.85, sheen=0.4, spec=0.3), 'sole': dict(rough=0.7),
        'M_hair': dict(rough=0.55, sheen=0.3), 'C_hair': dict(rough=0.55, sheen=0.3),
        'C_hair_dk': dict(rough=0.6), 'C_hair_lt': dict(rough=0.5),
        'copper': dict(rough=0.32, metal=0.85), 'strap': dict(rough=0.7), 'lens': dict(rough=0.05, coat=1.0, spec=0.8),
        'gold': dict(rough=0.25, metal=0.9), 'gold_dk': dict(rough=0.3, metal=0.9), 'dial': dict(rough=0.3, coat=0.5),
        'button': dict(rough=0.25, coat=0.6), 'blush': dict(rough=0.7, spec=0.2),
    }.get(key, {})
    base.update(preset); base.update(kw)
    return mat('wiw_' + key, PAL[key], **base)

# ---------------------------------------------------------------- face geometry on the head ellipsoid
def head_pt(x, z, out=0.0):
    """Point on the FRONT of the head at offset (x, z) from the head centre, pushed 'out' along the normal."""
    t = 1 - (x / HR.x) ** 2 - (z / HR.z) ** 2
    y = -HR.y * math.sqrt(max(t, 0.0005))
    p = Vector((x, y, z))
    n = Vector((p.x / HR.x ** 2, p.y / HR.y ** 2, p.z / HR.z ** 2)).normalized()
    return HC + p + n * out, n

def head_dir_pt(d, scale=1.0, out=0.0):
    """Point on the head surface along unit direction d (from the centre)."""
    d = Vector(d).normalized()
    k = 1.0 / math.sqrt((d.x / HR.x) ** 2 + (d.y / HR.y) ** 2 + (d.z / HR.z) ** 2)
    p = d * k * scale
    n = Vector((p.x / HR.x ** 2, p.y / HR.y ** 2, p.z / HR.z ** 2)).normalized()
    return HC + p + n * out, n

def ellipsoid_mesh_dirs(seg=56, rings=36):
    prof = []
    for i in range(rings + 1):
        th = math.pi * i / rings - math.pi / 2
        prof.append((math.cos(th), math.sin(th)))
    return prof

def hair_cap(name, keep, material, coll, scale=1.07, thick=0.022):
    """Shell around the head; 'keep(d)' decides which directions carry hair."""
    import bmesh
    prof = ellipsoid_mesh_dirs()
    Mx = Matrix.Translation(HC) @ Matrix.Diagonal((HR.x * scale, HR.y * scale, HR.z * scale, 1))
    ob = lathe(name, prof, material, coll, seg=56, mtx=Mx, subsurf=0)
    bm = bmesh.new(); bm.from_mesh(ob.data)
    kill = [v for v in bm.verts if not keep(((v.co - HC) / 1.0).normalized())]
    bmesh.ops.delete(bm, geom=kill, context='VERTS')
    bm.to_mesh(ob.data); bm.free(); ob.data.shade_smooth()
    so = ob.modifiers.new('Thick', 'SOLIDIFY'); so.thickness = thick; so.offset = -1.0; so.use_even_offset = True
    sd = ob.modifiers.new('Subdiv', 'SUBSURF'); sd.levels = 1; sd.render_levels = 2
    return ob

# ---------------------------------------------------------------- armature
BONES = [
    # name, head, tail, parent, connect
    ('root', (0, 0, 0), (0, 0.25, 0), None, False),
    ('pelvis', (0, 0, 0.40), (0, 0, 0.52), 'root', False),
    ('spine', (0, 0, 0.52), (0, 0, 0.84), 'pelvis', True),
    ('head', (0, 0, 0.84), (0, 0, 1.30), 'spine', True),
]
for s, x in (('L', 1), ('R', -1)):
    BONES += [
        (f'upper_arm.{s}', (0.205 * x, 0, 0.785), (0.25 * x, 0.0, 0.605), 'spine', False),
        (f'forearm.{s}', (0.25 * x, 0.0, 0.605), (0.29 * x, -0.02, 0.445), f'upper_arm.{s}', True),
        (f'hand.{s}', (0.29 * x, -0.02, 0.445), (0.298 * x, -0.02, 0.36), f'forearm.{s}', True),
        (f'hand_ik.{s}', (0.29 * x, -0.02, 0.445), (0.298 * x, -0.02, 0.36), 'root', False),
        (f'elbow_pole.{s}', (0.30 * x, 0.40, 0.60), (0.30 * x, 0.48, 0.60), 'root', False),
        (f'thigh.{s}', (0.085 * x, 0, 0.40), (0.085 * x, -0.012, 0.24), 'pelvis', False),
        (f'shin.{s}', (0.085 * x, -0.012, 0.24), (0.085 * x, 0, 0.085), f'thigh.{s}', True),
        (f'foot_ik.{s}', (0.085 * x, 0, 0.085), (0.085 * x, -0.13, 0.085), 'root', False),
        (f'knee_pole.{s}', (0.085 * x, -0.55, 0.24), (0.085 * x, -0.63, 0.24), 'root', False),
    ]

def build_armature(name, coll):
    ad = bpy.data.armatures.new(name + '_rig')
    arm = bpy.data.objects.new(name + '_RIG', ad)
    link(arm, coll)
    bpy.context.view_layer.objects.active = arm
    bpy.ops.object.mode_set(mode='EDIT')
    eb = {}
    for n, h, t, p, c in BONES:
        b = ad.edit_bones.new(n)
        b.head, b.tail = Vector(h), Vector(t)
        b.roll = 0.0
        if p:
            b.parent = eb[p]; b.use_connect = c
        b.use_deform = not (n.startswith(('root', 'hand_ik', 'foot_ik', 'elbow_pole', 'knee_pole')))
        eb[n] = b
    bpy.ops.object.mode_set(mode='OBJECT')
    for pb in arm.pose.bones:
        pb.rotation_mode = 'QUATERNION'
    # IK: arms and legs (2-bone chains with pole targets); hands copy the IK target rotation.
    for s in ('L', 'R'):
        for chain, tgt, pole in ((f'forearm.{s}', f'hand_ik.{s}', f'elbow_pole.{s}'), (f'shin.{s}', f'foot_ik.{s}', f'knee_pole.{s}')):
            c = arm.pose.bones[chain].constraints.new('IK')
            c.target = arm; c.subtarget = tgt; c.pole_target = arm; c.pole_subtarget = pole
            c.chain_count = 2; c.use_stretch = False
        cr = arm.pose.bones[f'hand.{s}'].constraints.new('COPY_ROTATION')
        cr.target = arm; cr.subtarget = f'hand_ik.{s}'
    _fit_pole_angles(arm)
    ad.display_type = 'STICK'
    return arm

def _fit_pole_angles(arm):
    """Choose the IK pole angle that keeps every chain at its rest shape (checked numerically)."""
    for s in ('L', 'R'):
        for chain in (f'forearm.{s}', f'shin.{s}'):
            c = arm.pose.bones[chain].constraints['IK']
            mid = arm.pose.bones[chain].parent
            best = None
            for ang in range(-180, 181, 15):
                c.pole_angle = math.radians(ang)
                bpy.context.view_layer.update()
                err = (mid.matrix.to_translation() - mid.bone.matrix_local.to_translation()).length + \
                      (Vector(mid.tail) - mid.bone.tail_local).length + (Vector(arm.pose.bones[chain].tail) - arm.pose.bones[chain].bone.tail_local).length
                rot_err = (mid.matrix.to_3x3() - mid.bone.matrix_local.to_3x3())
                err += sum(abs(v) for row in rot_err for v in row) * 0.01
                if best is None or err < best[0]:
                    best = (err, ang)
            c.pole_angle = math.radians(best[1])
            arm['pole_' + chain] = best[1]

# ---------------------------------------------------------------- weights
def torso_w(p):
    w = smoothstep(0.46, 0.62, p.z)
    return {'pelvis': 1 - w, 'spine': w}

def arm_w(s):
    e = Vector(dict((b[0], b[1]) for b in BONES)[f'forearm.{s}'])
    sh = Vector(dict((b[0], b[1]) for b in BONES)[f'upper_arm.{s}'])
    def f(p):
        if p.z > sh.z - 0.01 and abs(p.x) < abs(sh.x) - 0.01:
            return {'spine': 1.0}
        w = smoothstep(e.z + 0.035, e.z - 0.035, p.z)
        return {f'upper_arm.{s}': 1 - w, f'forearm.{s}': w}
    return f

def leg_w(s):
    k = Vector(dict((b[0], b[1]) for b in BONES)[f'shin.{s}'])
    def f(p):
        w = smoothstep(k.z + 0.03, k.z - 0.03, p.z)
        return {f'thigh.{s}': 1 - w, f'shin.{s}': w}
    return f

# ---------------------------------------------------------------- body parts
COAT_PROF = [(0, 0.352), (0.255, 0.355), (0.272, 0.37), (0.264, 0.42), (0.25, 0.52), (0.242, 0.62), (0.239, 0.72),
             (0.233, 0.79), (0.216, 0.83), (0.17, 0.862), (0.11, 0.876), (0, 0.879)]
COAT_SY = 0.74

def coat_r(z):
    for (r0, z0), (r1, z1) in zip(COAT_PROF[1:-2], COAT_PROF[2:-1]):
        if z0 <= z <= z1:
            return r0 + (r1 - r0) * (z - z0) / (z1 - z0)
    return COAT_PROF[1][0]

def coat_front(x, z, out=0.0):
    a = coat_r(z); b = a * COAT_SY
    y = -b * math.sqrt(max(0.0, 1 - (x / a) ** 2))
    n = Vector((x / a ** 2, y / b ** 2, 0)).normalized()
    return Vector((x, y, z)) + n * out, n

def body(kind, coll, arm, parts):
    c = 'M' if kind == 'M' else 'C'
    coat = lathe(f'{kind}_coat', COAT_PROF, M(f'{c}_coat'), coll, seg=32, sx=1.0, sy=COAT_SY)
    add_outline(coat); skin(coat, arm, torso_w); parts.append(coat)
    # placket strip
    pts = [coat_front(0.0, z, 0.003)[0] for z in [0.855, 0.8, 0.72, 0.62, 0.52, 0.43, 0.372]]
    pl = tube(f'{kind}_placket', pts, 0.016, M(f'{c}_coat_dk'), coll, seg=8, flat=0.25, up=(0, -1, 0))
    skin(pl, arm, torso_w); parts.append(pl)
    # buttons (Max: three, Clara: one high button), on the wearer's left of the placket
    bz = [0.72, 0.62, 0.52] if kind == 'M' else [0.775]
    for i, z in enumerate(bz):
        p, n = coat_front(0.04, z, 0.004)
        b = ellipsoid(f'{kind}_button{i}', p, (0.019, 0.009, 0.019), M('button'), coll, rot=look_rot(n), seg=16, rings=8)
        skin(b, arm, torso_w); parts.append(b)
    # pocket flaps
    for s, x in (('L', 0.135), ('R', -0.135)):
        p, n = coat_front(x, 0.47, 0.006)
        fl = rbox(f'{kind}_pocket.{s}', p, (0.095, 0.014, 0.024), M(f'{c}_coat_dk'), coll, rot=look_rot(n), bevel=0.45)
        skin(fl, arm, torso_w); parts.append(fl)
    # sleeves, shoulder caps, cuffs, hands
    for s, x in (('L', 1), ('R', -1)):
        sh = Vector((0.205 * x, 0, 0.785)); el = Vector((0.25 * x, 0.0, 0.605)); wr = Vector((0.29 * x, -0.02, 0.445))
        pts = [Vector((0.15 * x, 0, 0.80)), sh]
        pts += [sh.lerp(el, t) for t in (0.33, 0.66)] + [el] + [el.lerp(wr, t) for t in (0.33, 0.66)] + [wr + (wr - el).normalized() * 0.01]
        rad = [0.058, 0.062, 0.06, 0.058, 0.056, 0.054, 0.052, 0.05]
        sl = tube(f'{kind}_sleeve.{s}', pts, rad, M(f'{c}_coat'), coll, seg=16)
        add_outline(sl, 0.005); skin(sl, arm, arm_w(s)); parts.append(sl)
        cap = ellipsoid(f'{kind}_shoulder.{s}', sh + Vector((-0.01 * x, 0, 0.005)), (0.068, 0.066, 0.066), M(f'{c}_coat'), coll)
        parent_bone(cap, arm, f'upper_arm.{s}'); parts.append(cap)
        cu = torus(f'{kind}_cuff.{s}', wr + (el - wr).normalized() * 0.012, 0.047, 0.016, M(f'{c}_coat_dk'), coll,
                   rot=(wr - el).to_track_quat('Z', 'Y'))
        parent_bone(cu, arm, f'forearm.{s}'); parts.append(cu)
        for h in hand(f'{kind}_hand.{s}', wr, x, coll):
            parent_bone(h, arm, f'hand.{s}'); parts.append(h)
    # legs + boots
    for s, x in (('L', 1), ('R', -1)):
        hip = Vector((0.085 * x, 0, 0.42)); kn = Vector((0.085 * x, -0.012, 0.24)); an = Vector((0.085 * x, 0, 0.10))
        pts = [hip, hip.lerp(kn, 0.5), kn, kn.lerp(an, 0.5), an]
        lg = tube(f'{kind}_leg.{s}', pts, [0.07, 0.068, 0.064, 0.06, 0.058], M('pants'), coll, seg=14)
        add_outline(lg, 0.005); skin(lg, arm, leg_w(s)); parts.append(lg)
        for b in boot(f'{kind}_boot.{s}', x, c, coll):
            parent_bone(b, arm, f'foot_ik.{s}'); parts.append(b)

def hand(name, wr, x, coll):
    """4-finger cartoon hand (thumb + 3 fingers). Palm faces the body at rest; fingers relaxed, slightly curled."""
    sk = M('skin'); out = []
    side = -x   # direction toward the body
    pc = wr + Vector((0.004 * x, 0, -0.045))
    palm = ellipsoid(name + '_palm', pc, (0.022, 0.04, 0.042), sk, coll, seg=16, rings=10)
    add_outline(palm, 0.004); out.append(palm)
    for i, y in enumerate((-0.022, 0.0, 0.022)):
        L = 0.052 - abs(y) * 0.25
        p0 = pc + Vector((0, y, -0.03))
        p1 = p0 + Vector((side * 0.006, y * 0.15, -L * 0.55))
        p2 = p1 + Vector((side * 0.016, y * 0.1, -L * 0.45))
        f = tube(f'{name}_f{i}', [p0, p1, p2], [0.0135, 0.0125, 0.0115], sk, coll, seg=10)
        add_outline(f, 0.003); out.append(f)
    t0 = pc + Vector((side * 0.008, -0.03, 0.005))
    t1 = t0 + Vector((side * 0.012, -0.022, -0.025)); t2 = t1 + Vector((side * 0.012, -0.01, -0.022))
    th = tube(f'{name}_thumb', [t0, t1, t2], [0.015, 0.0135, 0.012], sk, coll, seg=10)
    add_outline(th, 0.003); out.append(th)
    return out

def boot(name, x, c, coll):
    out = []
    bx = 0.085 * x
    shaft = lathe(name + '_shaft', [(0, 0.02), (0.07, 0.02), (0.074, 0.06), (0.072, 0.15), (0.074, 0.195), (0.066, 0.2), (0.052, 0.198), (0, 0.19)],
                  M(f'{c}_boot'), coll, seg=24, sx=1.0, sy=1.08, mtx=Matrix.Translation((bx, 0.01, 0)))
    add_outline(shaft, 0.005); out.append(shaft)
    toe = ellipsoid(name + '_toe', (bx, -0.07, 0.058), (0.072, 0.1, 0.05), M(f'{c}_boot'), coll)
    add_outline(toe, 0.005); out.append(toe)
    sole = rbox(name + '_sole', (bx, -0.035, 0.012), (0.16, 0.27, 0.024), M('sole'), coll, bevel=0.45)
    out.append(sole)
    band = torus(name + '_band', (bx, 0.01, 0.185), 0.072, 0.014, M(f'{c}_boot_dk'), coll, flat=1.4)
    band.scale = (1, 1.08, 1); out.append(band)
    return out

# ---------------------------------------------------------------- head
def head(kind, coll, arm, parts, ctrl):
    sk = M('skin')
    hd = ellipsoid(f'{kind}_head', HC, tuple(HR), sk, coll, seg=40, rings=24)
    add_outline(hd); parent_bone(hd, arm, 'head'); parts.append(hd)
    # eyes: white + iris + pupil + highlight, grouped under a pivot empty (gaze & blink)
    for s, x in (('L', 1), ('R', -1)):
        ez = 0.03
        c, n = head_pt(0.086 * x, ez, -0.013)
        piv = bpy.data.objects.new(f'{kind}_eye.{s}', None); piv.empty_display_size = 0.03
        link(piv, coll); piv.location = c; piv.rotation_mode = 'QUATERNION'; piv.rotation_quaternion = look_rot(n)
        bpy.context.view_layer.update()
        q = look_rot(n)
        wh = ellipsoid(f'{kind}_eyewhite.{s}', c, (0.046, 0.03, 0.058), M('white'), coll, rot=q, seg=20, rings=12)
        add_outline(wh, 0.0045)
        fwd = (q @ Vector((0, -1, 0)))
        ir = ellipsoid(f'{kind}_iris.{s}', c + fwd * 0.0255 + Vector((0, 0, -0.004)), (0.029, 0.009, 0.033), M('iris'), coll, rot=q, seg=16, rings=8)
        pu = ellipsoid(f'{kind}_pupil.{s}', c + fwd * 0.0315 + Vector((0, 0, -0.004)), (0.017, 0.006, 0.02), M('pupil'), coll, rot=q, seg=14, rings=8)
        hl = ellipsoid(f'{kind}_glint.{s}', c + fwd * 0.036 + Vector((0.009, 0, 0.008)), (0.0075, 0.003, 0.0075),
                       mat('wiw_glint', '#FFFFFF', emit='#FFFFFF', emit_str=2.0), coll, rot=q, seg=10, rings=6, subsurf=0)
        for o in (wh, ir, pu, hl):
            parent_obj(o, piv)
        parent_bone(piv, arm, 'head'); parts += [wh, ir, pu, hl]
        ctrl[f'eye.{s}'] = piv
        # brows
        bpiv = bpy.data.objects.new(f'{kind}_browpiv.{s}', None); bpiv.empty_display_size = 0.02; link(bpiv, coll)
        bc, bn = head_pt(0.088 * x, 0.128, 0.0)
        bpiv.location = bc
        bw = 0.05 if kind == 'M' else 0.046
        pts = [head_pt((0.088 + u * bw) * x, 0.128 + 0.012 * (1 - u * u) - 0.004 * u * x * 0, 0.006)[0] for u in (-1, -0.5, 0, 0.5, 1)]
        br = tube(f'{kind}_brow.{s}', pts, [0.008, 0.012, 0.013, 0.012, 0.008] if kind == 'M' else [0.006, 0.009, 0.0095, 0.009, 0.006],
                  mat('wiw_line', PAL['line'], rough=0.6), coll, seg=10, flat=0.55, up=bn)
        parent_obj(br, bpiv); parent_bone(bpiv, arm, 'head'); parts.append(br)
        ctrl[f'brow.{s}'] = bpiv
        if kind == 'C':   # two lashes at the outer top of each eye
            for k, (dx, dz) in enumerate(((0.045, 0.045), (0.054, 0.03))):
                p0 = head_pt((0.086 + dx * 0.78) * x, ez + dz * 0.95, 0.0)[0]
                p1 = head_pt((0.086 + dx * 1.05) * x, ez + dz * 1.25, 0.012)[0]
                la = tube(f'C_lash{k}.{s}', [p0, p1], [0.0045, 0.0025], mat('wiw_line', PAL['line']), coll, seg=6, subsurf=0)
                parent_bone(la, arm, 'head'); parts.append(la)
        # cheeks
        cp, cn = head_pt(0.142 * x, -0.045, -0.004)
        bl = ellipsoid(f'{kind}_blush.{s}', cp, (0.036, 0.006, 0.022), M('blush'), coll, rot=look_rot(cn), seg=16, rings=6)
        parent_bone(bl, arm, 'head'); parts.append(bl)
        if kind == 'M':
            ep = HC + Vector((0.238 * x, 0.012, -0.02))
            ear = ellipsoid(f'M_ear.{s}', ep, (0.028, 0.038, 0.048), sk, coll, rot=Quaternion((0, 0, 1), math.radians(-12 * x)), seg=14, rings=8)
            add_outline(ear, 0.004); parent_bone(ear, arm, 'head'); parts.append(ear)
    # mouths (switched by visibility keys): smile / O / flat
    line = mat('wiw_line', PAL['line'])
    lipm = mat('wiw_lip', PAL['C_lip'], rough=0.4) if kind == 'C' else line
    mz = -0.078
    pts = [head_pt(u * 0.056, mz + 0.022 * u * u, 0.003)[0] for u in (-1, -0.6, -0.25, 0, 0.25, 0.6, 1)]
    sm = tube(f'{kind}_mouth_smile', pts, [0.006, 0.008, 0.0095, 0.0095, 0.0095, 0.008, 0.006], lipm, coll, seg=8, flat=0.6, up=(0, -1, 0))
    mo_c, mo_n = head_pt(0.0, mz - 0.006, -0.006)
    mo = ellipsoid(f'{kind}_mouth_O', mo_c, (0.03, 0.01, 0.036), mat('wiw_mouthin', PAL['mouth_in'], rough=0.4), coll, rot=look_rot(mo_n), seg=18, rings=8)
    add_outline(mo, 0.004)
    # v3: tongue kept inside the mouth opening (only its top shows), darker tone; it used to stick out of the face
    tg = ellipsoid(f'{kind}_tongue', mo_c + mo_n * 0.004 + Vector((0, 0, -0.019)), (0.016, 0.005, 0.008), mat('wiw_tongue', '#B84A5E', rough=0.5), coll, rot=look_rot(mo_n), seg=12, rings=6)
    pts = [head_pt(u * 0.04, mz + 0.004 * math.sin(u * 3.1), 0.003)[0] for u in (-1, -0.5, 0, 0.5, 1)]
    fl = tube(f'{kind}_mouth_flat', pts, 0.0075, lipm, coll, seg=8, flat=0.6, up=(0, -1, 0))
    for o in (sm, mo, tg, fl):
        parent_bone(o, arm, 'head'); parts.append(o)
    ctrl['mouth'] = {'smile': [sm], 'O': [mo, tg], 'flat': [fl]}
    if kind == 'M':
        max_hair(coll, arm, parts)
    else:
        clara_hair(coll, arm, parts)
        clara_watch(coll, arm, parts)

def max_hair(coll, arm, parts):
    hm = M('M_hair')
    n = Vector((0, 1.0, 0.75)) / 1.25
    cap = hair_cap('M_hair_cap', lambda d: d.dot(n) > 0.075 and d.z > -0.55, hm, coll, scale=1.06, thick=0.024)
    add_outline(cap, 0.005); parent_bone(cap, arm, 'head'); parts.append(cap)
    # messy fringe: short curved locks along the front hairline, swept to Max's left
    for i, u in enumerate((-0.62, -0.38, -0.14, 0.1, 0.34, 0.58)):
        a = math.radians(u * 80)
        e = math.radians(48 + 6 * math.cos(i * 1.7))
        d = Vector((math.sin(a) * math.cos(e), -math.cos(a) * math.cos(e), math.sin(e)))
        p0, nn = head_dir_pt(d, 1.05)
        p1 = p0 + nn * 0.03 + Vector((0.025, -0.01, -0.045))
        p2 = p1 + Vector((0.03 + 0.01 * math.sin(i), -0.006, -0.03))
        lk = tube(f'M_lock{i}', [p0 - nn * 0.02, p0 + nn * 0.012, p1, p2], [0.032, 0.03, 0.02, 0.004], hm, coll, seg=10, flat=0.55, up=nn)
        add_outline(lk, 0.004); parent_bone(lk, arm, 'head'); parts.append(lk)
    # tuft: two curled spikes rising behind the goggles
    for i, (dx, curl) in enumerate(((-0.02, 1.0), (0.035, -0.7))):
        p0, nn = head_dir_pt(Vector((dx, 0.15, 1.0)), 1.04)
        pts = [p0 - nn * 0.02, p0 + Vector((0, 0, 0.05)), p0 + Vector((0.01 * curl, -0.02, 0.11)), p0 + Vector((0.04 * curl, -0.05, 0.145)), p0 + Vector((0.075 * curl, -0.05, 0.13))]
        tf = tube(f'M_tuft{i}', pts, [0.04, 0.035, 0.024, 0.012, 0.003], hm, coll, seg=12, flat=0.6, up=(1, 0, 0))
        add_outline(tf, 0.004); parent_bone(tf, arm, 'head'); parts.append(tf)
    # goggles strap around the head + two copper cups with cyan lenses
    ef, eb = math.radians(56), math.radians(14)
    def sdir(th):
        e = eb + (ef - eb) * (1 + math.cos(th)) / 2
        return Vector((math.cos(e) * math.sin(th), -math.cos(e) * math.cos(th), math.sin(e)))
    pts = [head_dir_pt(sdir(2 * math.pi * k / 48), 1.075)[0] for k in range(49)]
    st = tube('M_goggle_strap', pts, 0.026, M('strap'), coll, seg=10, flat=0.32, caps=False)
    parent_bone(st, arm, 'head'); parts.append(st)
    cups = []
    for s, th in (('L', 0.3), ('R', -0.3)):
        p, nn = head_dir_pt(sdir(th), 1.1)
        q = look_rot(nn)
        body = lathe(f'M_goggle_cup.{s}', [(0, 0.0), (0.05, 0.0), (0.054, 0.018), (0.05, 0.03), (0, 0.031)], M('copper'), coll, seg=24,
                     mtx=Matrix.Translation(p - nn * 0.012) @ (q @ Quaternion((1, 0, 0), math.radians(90))).to_matrix().to_4x4())
        rim = torus(f'M_goggle_rim.{s}', p + nn * 0.018, 0.05, 0.015, M('copper'), coll, rot=q @ Quaternion((1, 0, 0), math.radians(90)))
        ln = ellipsoid(f'M_goggle_lens.{s}', p + nn * 0.02, (0.043, 0.016, 0.043), M('lens'), coll, rot=q, seg=20, rings=10)
        for o in (body, rim, ln):
            add_outline(o, 0.004) if o is not ln else None
            parent_bone(o, arm, 'head'); parts.append(o)
        cups.append(p + nn * 0.02)
    br = tube('M_goggle_bridge', [cups[0].lerp(cups[1], 0.18), cups[0].lerp(cups[1], 0.5) + Vector((0, -0.006, 0.006)), cups[0].lerp(cups[1], 0.82)],
              0.011, M('copper'), coll, seg=8)
    parent_bone(br, arm, 'head'); parts.append(br)

def clara_hair(coll, arm, parts):
    hm = M('C_hair')
    n = Vector((0, 1.0, 0.35)).normalized()
    cap = hair_cap('C_hair_cap', lambda d: d.dot(n) > -0.24 and d.z > -0.62, hm, coll, scale=1.07, thick=0.03)
    add_outline(cap, 0.005); parent_bone(cap, arm, 'head'); parts.append(cap)
    # centre part (darker groove) and two lighter strand highlights per side
    pts = [head_dir_pt(Vector((0, -0.62 + 0.25 * k, 0.8 + 0.05 * k)), 1.095)[0] for k in range(6)]
    pt = tube('C_hair_part', pts, 0.006, M('C_hair_dk'), coll, seg=6)
    parent_bone(pt, arm, 'head'); parts.append(pt)
    # bangs: two soft lobes swept from the part to each temple
    for s, x in (('L', 1), ('R', -1)):
        ds = [Vector((0.02 * x, -0.62, 0.79)), Vector((0.32 * x, -0.66, 0.68)), Vector((0.58 * x, -0.6, 0.53)), Vector((0.78 * x, -0.5, 0.36)), Vector((0.9 * x, -0.38, 0.16))]
        pts = []; nrm = None
        for d in ds:
            p, nn = head_dir_pt(d, 1.075); pts.append(p); nrm = nn
        bg = tube(f'C_bang.{s}', pts, [0.022, 0.04, 0.042, 0.034, 0.012], hm, coll, seg=12, flat=0.42, up=nrm)
        add_outline(bg, 0.004); parent_bone(bg, arm, 'head'); parts.append(bg)
        for k in range(2):
            ds2 = [Vector(((0.08 + 0.2 * k) * x, -0.45 + 0.3 * k, 0.88)), Vector(((0.45 + 0.15 * k) * x, -0.2 + 0.25 * k, 0.8)), Vector(((0.75 + 0.1 * k) * x, 0.0 + 0.2 * k, 0.55))]
            pts = [head_dir_pt(d, 1.1)[0] for d in ds2]
            hl = tube(f'C_strand{k}.{s}', pts, [0.004, 0.006, 0.003], M('C_hair_lt'), coll, seg=6)
            parent_bone(hl, arm, 'head'); parts.append(hl)
        # braid: chain of lumps from behind the ear, pink tie, small tuft
        top = HC + Vector((0.235 * x, 0.06, -0.085))
        for k in range(5):
            c = top + Vector((0.012 * x * k, 0.004 * k, -0.07 * k))
            r = 0.95 ** k
            q = Quaternion((0, 1, 0), math.radians((14 if k % 2 else -14) * x)) @ Quaternion((0, 0, 1), math.radians(20 * x))
            lp = ellipsoid(f'C_braid{k}.{s}', c, (0.052 * r, 0.05 * r, 0.058 * r), hm, coll, rot=q, seg=18, rings=10)
            add_outline(lp, 0.004); parent_bone(lp, arm, 'head'); parts.append(lp)
        end = top + Vector((0.06 * x, 0.02, -0.35))
        tie = torus(f'C_tie.{s}', end, 0.032, 0.013, M('tie', rough=0.4, coat=0.3) if False else mat('wiw_tie', PAL['tie'], rough=0.4, coat=0.3), coll)
        parent_bone(tie, arm, 'head'); parts.append(tie)
        for k, dx in enumerate((-0.022, 0.0, 0.022)):
            t0 = end + Vector((dx * 0.6, 0, -0.005))
            tt = tube(f'C_tuft{k}.{s}', [t0, t0 + Vector((dx * 0.8, 0, -0.04)), t0 + Vector((dx * 1.6, 0, -0.075))], [0.02, 0.016, 0.003], hm, coll, seg=10)
            add_outline(tt, 0.003); parent_bone(tt, arm, 'head'); parts.append(tt)

def clara_watch(coll, arm, parts):
    """Gold 'What If' pocket watch with a red '?' on the dial, on a chain around the neck."""
    wc, wn = coat_front(0.0, 0.62, 0.016)
    q = look_rot(wn)
    rot90 = (q @ Quaternion((1, 0, 0), math.radians(90))).to_matrix().to_4x4()
    case = lathe('C_watch_case', [(0, -0.012), (0.066, -0.012), (0.074, -0.004), (0.074, 0.006), (0.068, 0.014), (0.06, 0.016), (0, 0.016)],
                 M('gold'), coll, seg=32, mtx=Matrix.Translation(wc) @ rot90)
    add_outline(case, 0.004)
    dial = lathe('C_watch_dial', [(0, 0.0), (0.058, 0.0), (0.058, 0.004), (0, 0.004)], M('dial'), coll, seg=32,
                 mtx=Matrix.Translation(wc + wn * 0.014) @ rot90, subsurf=0)
    objs = [case, dial]
    for k in range(12):
        a = 2 * math.pi * k / 12
        lp = Vector((math.sin(a) * 0.049, 0, math.cos(a) * 0.049))
        tk = rbox(f'C_tick{k}', wc + wn * 0.019 + (q @ lp), (0.004, 0.003, 0.011 if k % 3 == 0 else 0.007), mat('wiw_line', PAL['line']), coll,
                  rot=q @ Quaternion((0, 1, 0), -a), bevel=0.3, subsurf=0)
        objs.append(tk)
    crown = lathe('C_watch_crown', [(0, 0.0), (0.012, 0.0), (0.012, 0.016), (0.008, 0.02), (0, 0.02)], M('gold_dk'), coll, seg=16,
                  mtx=Matrix.Translation(wc + (q @ Vector((0, 0, 0.072)))))
    ring = torus('C_watch_ring', wc + (q @ Vector((0, 0, 0.1))), 0.014, 0.004, M('gold_dk'), coll, rot=q @ Quaternion((1, 0, 0), 0))
    objs += [crown, ring]
    # red '?' (Blender's built-in font, extruded text converted to mesh)
    cu = bpy.data.curves.new('C_watch_q', 'FONT'); cu.body = '?'; cu.size = 0.07; cu.extrude = 0.002
    cu.align_x = 'CENTER'; cu.align_y = 'CENTER'
    to = bpy.data.objects.new('C_watch_q', cu); link(to, coll)
    to.rotation_mode = 'QUATERNION'; to.rotation_quaternion = q @ Quaternion((1, 0, 0), math.radians(90))
    to.location = wc + wn * 0.0215 + (q @ Vector((0.0, 0, -0.003)))
    cu.materials.append(mat('wiw_red', PAL['red'], rough=0.35, coat=0.4))
    objs.append(to)
    # chain: from behind the neck, over the shoulders, down to the ring
    for s, x in (('L', 1), ('R', -1)):
        pts = [Vector((0.09 * x, 0.1, 0.875)), Vector((0.13 * x, -0.02, 0.868)), coat_front(0.11 * x, 0.8, 0.006)[0],
               coat_front(0.06 * x, 0.72, 0.008)[0], wc + (q @ Vector((0.006 * x, 0, 0.11)))]
        ch = tube(f'C_chain.{s}', pts, 0.0055, M('gold_dk'), coll, seg=6)
        objs.append(ch)
    for o in objs:
        parent_bone(o, arm, 'spine'); parts.append(o)

# ---------------------------------------------------------------- public
def build(kind, coll_name=None, location=(0, 0, 0), yaw_deg=0.0):
    """kind 'M' (Max) or 'C' (Clara). Returns dict(rig=armature, ctrl=face controls, parts=[objects])."""
    coll = bpy.data.collections.new(coll_name or ('Max' if kind == 'M' else 'Clara'))
    bpy.context.scene.collection.children.link(coll)
    arm = build_armature('Max' if kind == 'M' else 'Clara', coll)
    parts, ctrl = [], {}
    body(kind, coll, arm, parts)
    head(kind, coll, arm, parts, ctrl)
    arm.location = location
    arm.rotation_euler = (0, 0, math.radians(yaw_deg))
    bpy.context.view_layer.update()
    return {'rig': arm, 'ctrl': ctrl, 'parts': parts, 'coll': coll}

def show_mouth(ctrl, which, frame):
    """Key the visible mouth shape at 'frame' (constant interpolation)."""
    for k, objs in ctrl['mouth'].items():
        for o in objs:
            o.hide_render = (k != which); o.hide_viewport = (k != which)
            o.keyframe_insert('hide_render', frame=frame); o.keyframe_insert('hide_viewport', frame=frame)
