# Turnaround previews of the stylized 3D Clara & Max (Cycles CPU).
# Run:  python preview_chars.py [outdir] [samples]   (bpy module)  or  blender -b -P preview_chars.py -- [outdir] [samples]
import sys, os, math, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bpy
from mathutils import Vector
argv = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else sys.argv[1:]
OUT = argv[0] if argv else os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'previews')
SAMPLES = int(argv[1]) if len(argv) > 1 else 48
os.makedirs(OUT, exist_ok=True)

bpy.ops.wm.read_factory_settings(use_empty=True)
import addon_utils; addon_utils.enable('cycles')
import wiw3d_lib as L
import wiw3d_chars as C

sc = bpy.context.scene
studio = bpy.data.collections.new('Studio'); sc.collection.children.link(studio)
# curved backdrop (cyclorama)
verts, faces = [], []
prof = [(-5, 0)] + [(1.5 + math.sin(a) * 1.2, 1.2 - math.cos(a) * 1.2) for a in [i * math.pi / 2 / 10 for i in range(11)]] + [(2.7, 5)]
for x in (-6, 6):
    for y, z in prof:
        verts.append((x, y, z))
n = len(prof)
faces = [(i, i + 1, n + i + 1, n + i) for i in range(n - 1)]
bd = L.mesh_from('backdrop', verts, faces, L.mat('studio', '#F2E6D6', rough=0.8), studio, subsurf=0)

def area(name, loc, target, power, size, color):
    ld = bpy.data.lights.new(name, 'AREA'); ld.energy = power; ld.size = size; ld.color = L.hexcol(color)[:3]
    ob = bpy.data.objects.new(name, ld); studio.objects.link(ob); ob.location = loc
    ob.rotation_euler = (Vector(target) - Vector(loc)).to_track_quat('-Z', 'Y').to_euler()
    return ob
area('key', (-2.2, -3.0, 3.0), (0, 0, 0.7), 420, 2.0, '#FFE4C4')
area('fill', (3.0, -2.4, 1.6), (0, 0, 0.7), 140, 2.5, '#E8F0FF')
area('rim', (1.2, 2.6, 2.8), (0, 0, 0.9), 260, 1.5, '#FFF2DF')
w = bpy.data.worlds.new('w'); sc.world = w
w.node_tree.nodes['Background'].inputs['Color'].default_value = L.hexcol('#3a3330')
w.node_tree.nodes['Background'].inputs['Strength'].default_value = 0.35

cd = bpy.data.cameras.new('cam'); cd.lens = 55
cam = bpy.data.objects.new('cam', cd); studio.objects.link(cam); sc.camera = cam
if os.environ.get('PREV_CLOSE'):
    cd.lens = 85; cam.location = (0, -2.2, 1.12); aim = Vector((0, 0, 1.08))
else:
    cam.location = (0, -4.1, 0.95); aim = Vector((0, 0, 0.68))
cam.rotation_euler = (aim - cam.location).to_track_quat('-Z', 'Y').to_euler()

sc.render.engine = 'CYCLES'; sc.cycles.device = 'CPU'; sc.cycles.samples = SAMPLES
sc.cycles.use_denoising = True; sc.cycles.max_bounces = 6; sc.cycles.transparent_max_bounces = 8
RES = float(os.environ.get('PREV_SCALE', '1'))
sc.render.resolution_x = int(800 * RES); sc.render.resolution_y = int(1000 * RES)
sc.view_settings.view_transform = os.environ.get('PREV_VT', 'Standard'); sc.view_settings.look = os.environ.get('PREV_LOOK', 'None'); sc.view_settings.exposure = float(os.environ.get('PREV_EXP', '-1.3'))

chars = {}
for kind in ('C', 'M'):
    chars[kind] = C.build(kind)
times = []
KINDS = os.environ.get('PREV_KINDS', 'CM')
for kind in KINDS:
    for k2, ch in chars.items():
        ch['coll'].hide_render = (k2 != kind)
        # restore mouth visibility (only smile visible)
        if k2 == kind:
            for mk, objs in ch['ctrl']['mouth'].items():
                for o in objs:
                    o.hide_render = (mk != 'smile')
    rig = chars[kind]['rig']
    for yaw in [int(v) for v in os.environ.get('PREV_YAWS', '0,35,90,180').split(',')]:
        rig.rotation_euler = (0, 0, math.radians(yaw))
        sc.render.filepath = os.path.join(OUT, f'{kind}_{yaw:03d}.png')
        t = time.time(); bpy.ops.render.render(write_still=True); times.append(time.time() - t)
        print('rendered', kind, yaw, round(times[-1], 1), flush=True)
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, 'characters_preview.blend'))
print('avg s/frame', round(sum(times) / len(times), 1))
