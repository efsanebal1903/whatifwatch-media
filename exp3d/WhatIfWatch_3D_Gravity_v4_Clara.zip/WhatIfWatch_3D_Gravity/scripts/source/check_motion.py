# Numeric motion checks for the gravity test: foot sliding, floating, IK detachment, interpenetration, landings.
# Run: python check_motion.py scene.blend report.json [step]
import sys, os, json, math
import bpy
from mathutils import Vector
from mathutils.bvhtree import BVHTree
argv = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else sys.argv[1:]
BLEND, OUT = argv[0], argv[1]
STEP = int(argv[2]) if len(argv) > 2 else 1
bpy.ops.wm.open_mainfile(filepath=BLEND)
sc = bpy.context.scene
rig = bpy.data.objects['Max_RIG']
TOP = 0.62
def objs(prefix):
    return [o for o in bpy.data.objects if o.type == 'MESH' and o.name.startswith(prefix) and not o.hide_render]
def bvh(obs, dg):
    verts, polys, off = [], [], 0
    for o in obs:
        oe = o.evaluated_get(dg); me = oe.to_mesh()
        mw = oe.matrix_world
        verts += [mw @ v.co for v in me.vertices]
        polys += [[i + off for i in p.vertices] for p in me.polygons]
        off += len(me.vertices); oe.to_mesh_clear()
    return BVHTree.FromPolygons(verts, polys, all_triangles=False), verts
groups = {
    'max_hand_R': lambda: objs('M_hand.R') , 'max_hand_L': lambda: objs('M_hand.L'),
    'max_sleeve_R': lambda: objs('M_sleeve.R'), 'max_sleeve_L': lambda: objs('M_sleeve.L'),
    'max_boots': lambda: objs('M_boot'), 'max_legs': lambda: objs('M_leg'), 'max_coat': lambda: objs('M_coat'),
    'max_head': lambda: [o for o in objs('M_') if any(o.name.startswith(p) for p in ('M_head', 'M_hair', 'M_lock', 'M_tuft', 'M_goggle', 'M_ear'))],
    'table': lambda: objs('table_'), 'mug': lambda: [o for o in bpy.data.objects if o.type == 'MESH' and o.name in ('mug', 'mug_handle', 'mug_band')],
    'apple': lambda: [o for o in bpy.data.objects if o.type == 'MESH' and o.name in ('apple',)],
    'books': lambda: objs('table_book'), 'rug': lambda: objs('rug'),
    'clara_hand_R': lambda: objs('C_hand.R'), 'clara_hand_L': lambda: objs('C_hand.L'), 'clara_coat': lambda: objs('C_coat'),
    'clara_head': lambda: [o for o in objs('C_') if any(o.name.startswith(p) for p in ('C_head', 'C_hair', 'C_bang', 'C_braid', 'C_tie', 'C_tuft'))],
    'clara_body': lambda: [o for o in objs('C_') if any(o.name.startswith(p) for p in ('C_coat', 'C_sleeve', 'C_leg', 'C_boot', 'C_hand'))],
    'max_body': lambda: [o for o in objs('M_') if any(o.name.startswith(p) for p in ('M_coat', 'M_sleeve', 'M_leg', 'M_boot', 'M_hand'))],
}
pairs = [('max_hand_R', 'table'), ('max_hand_L', 'table'), ('max_hand_L', 'mug'), ('max_hand_R', 'mug'), ('max_hand_L', 'apple'),
         ('max_hand_R', 'apple'), ('max_sleeve_R', 'table'), ('max_sleeve_L', 'table'), ('max_boots', 'table'), ('max_legs', 'table'),
         ('max_coat', 'table'), ('max_hand_L', 'max_coat'), ('max_hand_R', 'max_coat'), ('max_hand_L', 'max_head'), ('max_hand_R', 'max_head'),
         ('clara_hand_R', 'clara_coat'), ('clara_hand_L', 'clara_coat'), ('clara_hand_R', 'clara_head'), ('clara_hand_L', 'clara_head'), ('clara_body', 'max_body'), ('clara_body', 'table'),
         ('mug', 'table'), ('apple', 'table'), ('mug', 'books'), ('apple', 'books'), ('mug', 'apple'), ('max_boots', 'max_boots')]
rep = {'overlaps': {}, 'foot': {}, 'ik_gap_max_mm': {}, 'sole_z_mm': {}, 'min_dist_hand_obj_m': {}, 'landing': {}}
foot_pos = {'L': [], 'R': []}
ik_gap = {k: 0.0 for k in ('arm.L', 'arm.R', 'leg.L', 'leg.R')}
sole_min = {'L': [], 'R': []}
min_dist = {'hand_L-mug': 9, 'hand_R-mug': 9, 'hand_L-apple': 9, 'hand_R-apple': 9}
mug_minz = []; app_minz = []
for f in range(sc.frame_start, sc.frame_end + 1, STEP):
    sc.frame_set(f); dg = bpy.context.evaluated_depsgraph_get()
    P = rig.pose.bones; W = rig.matrix_world
    for s in 'LR':
        foot_pos[s].append((f, tuple(W @ P[f'foot_ik.{s}'].head)))
        ik_gap[f'leg.{s}'] = max(ik_gap[f'leg.{s}'], ((W @ P[f'shin.{s}'].tail) - (W @ P[f'foot_ik.{s}'].head)).length)
        ik_gap[f'arm.{s}'] = max(ik_gap[f'arm.{s}'], ((W @ P[f'forearm.{s}'].tail) - (W @ P[f'hand_ik.{s}'].head)).length)
        so = bpy.data.objects[f'M_boot.{s}_sole'].evaluated_get(dg)
        sole_min[s].append((f, min((so.matrix_world @ v.co).z for v in so.to_mesh().vertices))); so.to_mesh_clear()
    T = {k: bvh(g(), dg) for k, g in groups.items()}
    for a, b in pairs:
        if a == b:
            continue
        hits = T[a][0].overlap(T[b][0])
        if hits:
            rep['overlaps'].setdefault(f'{a}~{b}', []).append(f)
    for h in 'LR':
        hv = T[f'max_hand_{h}'][1]
        for o in ('mug', 'apple'):
            tree = T[o][0]
            d = min((tree.find_nearest(v)[3] for v in hv[::7]), default=9)
            min_dist[f'hand_{h}-{o}'] = min(min_dist[f'hand_{h}-{o}'], d)
    mug_minz.append((f, min(v.z for v in T['mug'][1]))); app_minz.append((f, min(v.z for v in T['apple'][1])))
# foot sliding: displacement while planted (right foot always; left foot before 206 and from 228)
def drift(lst, frames):
    pts = [Vector(p) for f, p in lst if f in frames]
    return max((p - pts[0]).length for p in pts) if pts else None
allf = set(range(sc.frame_start, sc.frame_end + 1))
rep['foot']['R_planted_drift_mm'] = round(drift(foot_pos['R'], allf) * 1000, 3)
rep['foot']['L_planted_drift_before_step_mm'] = round(drift(foot_pos['L'], set(range(1, 206))) * 1000, 3)
rep['foot']['L_planted_drift_after_step_mm'] = round(drift(foot_pos['L'], set(range(228, 313))) * 1000, 3)
rep['ik_gap_max_mm'] = {k: round(v * 1000, 3) for k, v in ik_gap.items()}
for s in 'LR':
    planted = [z for f, z in sole_min[s] if (s == 'R' or f < 206 or f >= 228)]
    rep['sole_z_mm'][s] = {'min': round(min(planted) * 1000, 2), 'max': round(max(planted) * 1000, 2)}
rep['min_dist_hand_obj_m'] = {k: round(v, 4) for k, v in min_dist.items()}
rep['landing'] = {
    'mug_bottom_start_mm_above_top': round((mug_minz[0][1] - TOP) * 1000, 2), 'mug_bottom_end_mm_above_top': round((mug_minz[-1][1] - TOP) * 1000, 2),
    'mug_lowest_mm_above_top': round((min(z for f, z in mug_minz) - TOP) * 1000, 2),
    'apple_bottom_start_mm': round((app_minz[0][1] - TOP) * 1000, 2), 'apple_bottom_end_mm': round((app_minz[-1][1] - TOP) * 1000, 2),
    'apple_lowest_mm': round((min(z for f, z in app_minz) - TOP) * 1000, 2),
}
rep['overlaps'] = {k: {'count': len(v), 'frames': v[:12] + (['...'] if len(v) > 12 else []), 'first': v[0], 'last': v[-1]} for k, v in rep['overlaps'].items()}
rep['step'] = STEP
json.dump(rep, open(OUT, 'w'), indent=1)
print(json.dumps(rep, indent=1))
