# Builds the simplified EEVEE test scene from the Cycles scene (scene preparation only, no rendering).
# Characters, rig, animation and cameras are untouched; only render engine, lights and effects are simplified.
# Run: blender -b scene\gravity_test.blend -P scripts\source\make_eevee_test.py -- scene\gravity_eevee_test.blend
import sys, os
import bpy
argv = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
OUT = argv[0]
sc = bpy.context.scene
log = []
def setp(obj, name, value):
    if hasattr(obj, name):
        try:
            setattr(obj, name, value); log.append(f'{name}={value}')
        except (TypeError, ValueError) as e:
            log.append(f'{name} NOT SET ({e})')

# engine: EEVEE, low sample count, no ray tracing, simple shadows
sc.render.engine = 'BLENDER_EEVEE'
e = sc.eevee
setp(e, 'taa_render_samples', 16)
setp(e, 'use_raytracing', False)
setp(e, 'use_shadows', True)
setp(e, 'shadow_ray_count', 1)
setp(e, 'shadow_step_count', 4)
setp(e, 'shadow_resolution_scale', 1.0)   # v2: sharper contact under objects
setp(e, 'use_volumetric_shadows', False)
# effects off
sc.render.use_motion_blur = False
for o in bpy.data.objects:
    if o.type == 'CAMERA':
        o.data.dof.use_dof = False
# lights: 5 -> 3 (window key, front key, fill); rim and lamp point light removed. Lamp shade stays emissive.
for n in ('L_rim', 'L_lamp'):
    if n in bpy.data.objects:
        bpy.data.objects.remove(bpy.data.objects[n], do_unlink=True)
# without global illumination EEVEE has no bounce light: compensate with a brighter fill and world
if 'L_key' in bpy.data.objects:
    bpy.data.objects['L_key'].data.size = 0.8      # v2: smaller key light -> more readable shadows
if 'L_fill' in bpy.data.objects:
    bpy.data.objects['L_fill'].data.energy = 140
sc.world.node_tree.nodes['Background'].inputs['Strength'].default_value = 0.6
# materials: subsurface off on skin (cheaper, almost no visible change at this scale)
for m in bpy.data.materials:
    if m.node_tree and m.node_tree.nodes.get('Principled BSDF'):
        p = m.node_tree.nodes['Principled BSDF']
        if p.inputs['Subsurface Weight'].default_value > 0:
            p.inputs['Subsurface Weight'].default_value = 0.0; log.append(f'SSS off: {m.name}')
# geometry: subdivision render level 2 -> 1 (identity/silhouettes unchanged, ~4x fewer triangles)
n = 0
for o in bpy.data.objects:
    for md in o.modifiers:
        if md.type == 'SUBSURF':
            md.render_levels = 1; n += 1
log.append(f'subdiv render level 1 on {n} objects')
sc.render.resolution_x, sc.render.resolution_y, sc.render.resolution_percentage = 1920, 1080, 100
bpy.ops.wm.save_as_mainfile(filepath=os.path.abspath(OUT))
print('EEVEE test scene saved:', OUT); print('\n'.join(log))
