# What If Watch — stylized 3D experiment: geometry + material helpers (Blender 5.0 Python API)
# Everything is generated procedurally; no external models, textures or HDRIs are used.
import bpy, bmesh, math
from mathutils import Vector, Matrix, Quaternion

# ---------------------------------------------------------------- colours
def srgb2lin(c):
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4

def hexcol(h, a=1.0):
    h = h.lstrip('#')
    return (srgb2lin(int(h[0:2], 16) / 255), srgb2lin(int(h[2:4], 16) / 255), srgb2lin(int(h[4:6], 16) / 255), a)

_MATS = {}

def mat(name, color, rough=0.55, metal=0.0, coat=0.0, emit=None, emit_str=0.0, sss=0.0, sheen=0.0, spec=0.5, alpha=1.0):
    """Principled BSDF material (input names verified on bpy 5.0.1)."""
    if name in _MATS:
        return _MATS[name]
    m = bpy.data.materials.new(name)
    nt = m.node_tree
    p = nt.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value = hexcol(color) if isinstance(color, str) else color
    p.inputs['Roughness'].default_value = rough
    p.inputs['Metallic'].default_value = metal
    p.inputs['Coat Weight'].default_value = coat
    p.inputs['Specular IOR Level'].default_value = spec
    p.inputs['Sheen Weight'].default_value = sheen
    if sss:
        p.inputs['Subsurface Weight'].default_value = sss
        p.inputs['Subsurface Radius'].default_value = (0.9, 0.45, 0.3)
        p.inputs['Subsurface Scale'].default_value = 0.02
    if emit:
        p.inputs['Emission Color'].default_value = hexcol(emit) if isinstance(emit, str) else emit
        p.inputs['Emission Strength'].default_value = emit_str
    if alpha < 1:
        p.inputs['Alpha'].default_value = alpha
    m.diffuse_color = hexcol(color) if isinstance(color, str) else color   # viewport/workbench colour
    _MATS[name] = m
    return m

def outline_mat():
    """Inverted-hull outline: dark where the hull faces the camera, transparent where it faces away."""
    if 'OUTLINE' in _MATS:
        return _MATS['OUTLINE']
    m = bpy.data.materials.new('OUTLINE')
    nt = m.node_tree
    for n in list(nt.nodes):
        nt.nodes.remove(n)
    out = nt.nodes.new('ShaderNodeOutputMaterial')
    geo = nt.nodes.new('ShaderNodeNewGeometry')
    mix = nt.nodes.new('ShaderNodeMixShader')
    em = nt.nodes.new('ShaderNodeEmission')
    em.inputs['Color'].default_value = hexcol('#1d1b2e')
    em.inputs['Strength'].default_value = 1.0
    tr = nt.nodes.new('ShaderNodeBsdfTransparent')
    nt.links.new(geo.outputs['Backfacing'], mix.inputs['Fac'])
    nt.links.new(em.outputs['Emission'], mix.inputs[1])
    nt.links.new(tr.outputs['BSDF'], mix.inputs[2])
    nt.links.new(mix.outputs['Shader'], out.inputs['Surface'])
    m.diffuse_color = hexcol('#1d1b2e')
    _MATS['OUTLINE'] = m
    return m

# ---------------------------------------------------------------- object helpers
def link(ob, coll):
    coll.objects.link(ob)
    return ob

def mesh_from(name, verts, faces, material, coll, smooth=True, subsurf=1, render_levels=2):
    me = bpy.data.meshes.new(name)
    me.from_pydata([tuple(v) for v in verts], [], faces)
    me.validate()
    if smooth:
        me.shade_smooth()
    ob = bpy.data.objects.new(name, me)
    if material is not None:
        me.materials.append(material)
    link(ob, coll)
    if subsurf:
        sd = ob.modifiers.new('Subdiv', 'SUBSURF')
        sd.levels = subsurf
        sd.render_levels = render_levels
    return ob

USE_OUTLINE = False   # tested: the inverted hull was invisible/costly in Cycles; the clean 3D look is kept

def add_outline(ob, thick=0.006):
    """Thin inverted-hull outline (only on the large silhouette forms). Disabled by default."""
    if not USE_OUTLINE:
        return None
    om = outline_mat()
    ob.data.materials.append(om)
    s = ob.modifiers.new('Outline', 'SOLIDIFY')
    s.thickness = thick
    s.offset = 1.0
    s.use_flip_normals = False
    s.use_rim = False
    s.material_offset = len(ob.data.materials) - 1
    return s

def _ring_frame(t, prev_n=None):
    t = t.normalized()
    if prev_n is None:
        a = Vector((0, 0, 1)) if abs(t.z) < 0.9 else Vector((1, 0, 0))
        n = (a - t * a.dot(t)).normalized()
    else:
        n = (prev_n - t * prev_n.dot(t)).normalized()
    b = t.cross(n).normalized()
    return n, b

def tube(name, pts, radii, material, coll, seg=12, flat=1.0, caps=True, subsurf=1, render_levels=2, up=None, twist=0.0):
    """Tube along a polyline with per-point radius. flat<1 squashes the section along the binormal.
    up: optional vector to fix the section orientation (used for flat straps / brows)."""
    pts = [Vector(p) for p in pts]
    n_pts = len(pts)
    if not hasattr(radii, '__len__'):
        radii = [radii] * n_pts
    verts, faces = [], []
    n_prev = None
    for i, p in enumerate(pts):
        t = (pts[min(i + 1, n_pts - 1)] - pts[max(i - 1, 0)])
        if up is not None:
            u = Vector(up)
            n = (u - t.normalized() * u.dot(t.normalized())).normalized()
            b = t.normalized().cross(n).normalized()
        else:
            n, b = _ring_frame(t, n_prev)
        n_prev = n
        r = radii[i]
        for k in range(seg):
            a = 2 * math.pi * k / seg + twist * i
            verts.append(p + n * (math.cos(a) * r) + b * (math.sin(a) * r * flat))
    for i in range(n_pts - 1):
        for k in range(seg):
            a0 = i * seg + k; a1 = i * seg + (k + 1) % seg
            faces.append((a0, a1, a1 + seg, a0 + seg))
    if caps:
        c0 = len(verts); verts.append(pts[0] - (pts[1] - pts[0]).normalized() * radii[0] * 0.35)
        faces += [(c0, (k + 1) % seg, k) for k in range(seg)]
        c1 = len(verts); verts.append(pts[-1] + (pts[-1] - pts[-2]).normalized() * radii[-1] * 0.35)
        base = (n_pts - 1) * seg
        faces += [(c1, base + k, base + (k + 1) % seg) for k in range(seg)]
    return mesh_from(name, verts, faces, material, coll, subsurf=subsurf, render_levels=render_levels)

def lathe(name, prof, material, coll, seg=24, sx=1.0, sy=1.0, mtx=None, subsurf=1, render_levels=2, ring_scale=None):
    """Surface of revolution around local +Z. prof = [(r, z), ...] from bottom to top.
    A ring with r == 0 becomes a pole. ring_scale(i) -> (sx, sy, dx, dy) per ring (optional)."""
    verts, faces, rings = [], [], []
    for i, (r, z) in enumerate(prof):
        rsx, rsy, dx, dy = (sx, sy, 0.0, 0.0) if ring_scale is None else ring_scale(i, r, z)
        if r <= 1e-6:
            rings.append([len(verts)]); verts.append(Vector((dx, dy, z)))
        else:
            idx = []
            for k in range(seg):
                a = 2 * math.pi * k / seg
                idx.append(len(verts)); verts.append(Vector((math.cos(a) * r * rsx + dx, math.sin(a) * r * rsy + dy, z)))
            rings.append(idx)
    for i in range(len(rings) - 1):
        A, B = rings[i], rings[i + 1]
        if len(A) == 1 and len(B) > 1:
            faces += [(A[0], B[(k + 1) % seg], B[k]) for k in range(seg)]
        elif len(A) > 1 and len(B) == 1:
            faces += [(A[k], A[(k + 1) % seg], B[0]) for k in range(seg)]
        elif len(A) > 1 and len(B) > 1:
            faces += [(A[k], A[(k + 1) % seg], B[(k + 1) % seg], B[k]) for k in range(seg)]
    if mtx is not None:
        verts = [mtx @ v for v in verts]
    return mesh_from(name, verts, faces, material, coll, subsurf=subsurf, render_levels=render_levels)

def ellipsoid(name, center, radii, material, coll, rot=None, seg=20, rings=12, subsurf=1, render_levels=2):
    prof = []
    for i in range(rings + 1):
        th = math.pi * i / rings - math.pi / 2
        prof.append((math.cos(th), math.sin(th)))
    prof[0] = (0.0, -1.0); prof[-1] = (0.0, 1.0)
    M = Matrix.Translation(Vector(center))
    if rot is not None:
        M = M @ (rot.to_matrix().to_4x4() if isinstance(rot, Quaternion) else rot)
    M = M @ Matrix.Diagonal((radii[0], radii[1], radii[2], 1.0))
    return lathe(name, prof, material, coll, seg=seg, mtx=M, subsurf=subsurf, render_levels=render_levels)

def rbox(name, center, size, material, coll, rot=None, bevel=0.3, subsurf=2, render_levels=2):
    """Rounded box: cube + subdivision; 'bevel' (0..1) controls roundness via inner support loops."""
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    e = bevel
    bmesh.ops.bevel(bm, geom=list(bm.edges), offset=0.5 * max(0.02, min(0.49, e)), segments=2, affect='EDGES', profile=0.5)
    M = Matrix.Translation(Vector(center))
    if rot is not None:
        M = M @ (rot.to_matrix().to_4x4() if isinstance(rot, Quaternion) else rot)
    M = M @ Matrix.Diagonal((size[0], size[1], size[2], 1.0))
    bmesh.ops.transform(bm, matrix=M, verts=bm.verts)
    me = bpy.data.meshes.new(name); bm.to_mesh(me); bm.free()
    me.shade_smooth()
    ob = bpy.data.objects.new(name, me); me.materials.append(material); link(ob, coll)
    if subsurf:
        sd = ob.modifiers.new('Subdiv', 'SUBSURF'); sd.levels = 1; sd.render_levels = render_levels
    return ob

def torus(name, center, major, minor, material, coll, rot=None, seg=32, mseg=10, arc=2 * math.pi, flat=1.0, subsurf=1):
    pts = []
    closed = abs(arc - 2 * math.pi) < 1e-6
    n = seg if closed else seg + 1
    for i in range(n):
        a = arc * i / seg
        pts.append(Vector((math.cos(a) * major, math.sin(a) * major, 0)))
    verts, faces = [], []
    for i, p in enumerate(pts):
        radial = Vector((p.x, p.y, 0)).normalized()
        for k in range(mseg):
            b = 2 * math.pi * k / mseg
            verts.append(p + radial * (math.cos(b) * minor) + Vector((0, 0, math.sin(b) * minor * flat)))
    rng = seg if closed else seg
    for i in range(rng):
        j = (i + 1) % n
        if not closed and i == n - 1:
            break
        for k in range(mseg):
            faces.append((i * mseg + k, i * mseg + (k + 1) % mseg, j * mseg + (k + 1) % mseg, j * mseg + k))
    M = Matrix.Translation(Vector(center))
    if rot is not None:
        M = M @ (rot.to_matrix().to_4x4() if isinstance(rot, Quaternion) else rot)
    verts = [M @ v for v in verts]
    return mesh_from(name, verts, faces, material, coll, subsurf=subsurf)

def look_rot(direction, up=Vector((0, 0, 1))):
    """Quaternion that turns local -Y toward 'direction' (our 'front' convention), local +Z toward up."""
    d = Vector(direction).normalized()
    return d.to_track_quat('-Y', 'Z')

# ---------------------------------------------------------------- armature helpers
def parent_bone(ob, arm, bone):
    """Rigidly attach object to a bone, keeping its current world transform (rest pose)."""
    bpy.context.view_layer.update()
    mw = ob.matrix_world.copy()
    ob.parent = arm
    ob.parent_type = 'BONE'
    ob.parent_bone = bone
    pb = arm.pose.bones[bone]
    ob.matrix_parent_inverse = (arm.matrix_world @ pb.matrix @ Matrix.Translation((0, pb.bone.length, 0))).inverted()
    ob.matrix_basis = Matrix.Identity(4)
    ob.matrix_world = mw
    return ob

def parent_obj(ob, parent):
    bpy.context.view_layer.update()
    mw = ob.matrix_world.copy()
    ob.parent = parent
    ob.matrix_parent_inverse = parent.matrix_world.inverted()
    ob.matrix_world = mw
    return ob

def skin(ob, arm, weight_fn):
    """Armature-deform an object: weight_fn(world_co) -> {bone: weight}. Armature goes first in the stack."""
    groups = {}
    mw = ob.matrix_world
    for v in ob.data.vertices:
        for b, w in weight_fn(mw @ v.co).items():
            if w <= 0:
                continue
            if b not in groups:
                groups[b] = ob.vertex_groups.new(name=b)
            groups[b].add([v.index], w, 'REPLACE')
    mod = ob.modifiers.new('Armature', 'ARMATURE')
    mod.object = arm
    while ob.modifiers[0] != mod:
        bpy.context.view_layer.objects.active = ob
        ob.modifiers.move(ob.modifiers.find(mod.name), 0)
    ob.parent = arm
    ob.matrix_parent_inverse = arm.matrix_world.inverted()
    return ob

def smoothstep(a, b, x):
    t = max(0.0, min(1.0, (x - a) / (b - a)))
    return t * t * (3 - 2 * t)

# ---------------------------------------------------------------- animation helpers
def channelbag(id_owner):
    """Blender 5.0: Action.fcurves was removed; F-Curves live in a channelbag per action slot."""
    from bpy_extras import anim_utils
    ad = id_owner.animation_data
    return anim_utils.action_get_channelbag_for_slot(ad.action, ad.action_slot)

def set_interp(id_owner, interp='BEZIER', data_path_contains=None, easing=None):
    ad = id_owner.animation_data
    if ad is None or ad.action is None:
        return
    for fc in channelbag(id_owner).fcurves:
        if data_path_contains and data_path_contains not in fc.data_path:
            continue
        for kp in fc.keyframe_points:
            kp.interpolation = interp
            if easing:
                kp.easing = easing
            kp.handle_left_type = 'AUTO_CLAMPED'
            kp.handle_right_type = 'AUTO_CLAMPED'
