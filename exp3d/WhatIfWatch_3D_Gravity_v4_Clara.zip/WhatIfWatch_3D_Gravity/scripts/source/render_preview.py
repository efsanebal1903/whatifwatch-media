# Fast preview renders. Run: python render_preview.py scene.blend outdir PROFILE f0 f1 [step]
# PROFILE: WB540 (Workbench 960x540) | CY360 (Cycles 640x360, 4 spp) | CY540 (Cycles 960x540, 4 spp)
# Cycles previews: denoise on, subdivision render level 0, no motion blur. The .blend on disk is not modified.
import sys, os, time
import bpy
argv = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else sys.argv[1:]
BLEND, OUT, PROF, f0, f1 = argv[0], argv[1], argv[2], int(argv[3]), int(argv[4])
step = int(argv[5]) if len(argv) > 5 else 1
bpy.ops.wm.open_mainfile(filepath=BLEND)
sc = bpy.context.scene
sc.render.use_motion_blur = False
if PROF == 'WB540':
    sc.render.engine = 'BLENDER_WORKBENCH'
    sh = sc.display.shading
    sh.light = 'STUDIO'; sh.color_type = 'MATERIAL'; sh.show_shadows = True; sh.show_cavity = True
    sc.render.resolution_x, sc.render.resolution_y = 960, 540
    sc.view_settings.exposure = 0.0
else:
    sc.render.engine = 'CYCLES'; sc.cycles.samples = 4; sc.cycles.use_denoising = True; sc.cycles.adaptive_threshold = 0.1
    sc.render.resolution_x, sc.render.resolution_y = (640, 360) if PROF == 'CY360' else (960, 540)
    for o in bpy.data.objects:
        for m in getattr(o, 'modifiers', []):
            if m.type == 'SUBSURF':
                m.render_levels = 0
sc.render.resolution_percentage = 100
sc.render.image_settings.file_format = 'JPEG'; sc.render.image_settings.quality = 90
os.makedirs(OUT, exist_ok=True)
times = []
for f in range(f0, f1 + 1, step):
    sc.frame_set(f); sc.render.filepath = os.path.join(OUT, f'p{f:04d}.jpg')
    t = time.time(); bpy.ops.render.render(write_still=True); times.append(time.time() - t)
print(PROF, 'frames', len(times), 'first', round(times[0], 1), 'avg', round(sum(times) / len(times), 2),
      'avg_after_first', round(sum(times[1:]) / max(1, len(times) - 1), 2))
