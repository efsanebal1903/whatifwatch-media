# 2/3) GPU render of the animation to PNG frames (resumable: existing frames are skipped).
# blender.exe -b scene\gravity_test.blend -P scripts\render_gpu.py -- <preview|final> [first] [last]
#   preview : 1280x720, 8 samples, no motion blur  -> render\preview\
#   final   : 1920x1080, the samples saved in the scene, motion blur on -> render\final\
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bpy
from gpu_common import enable_gpu
argv = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
mode = argv[0] if argv else 'preview'
enable_gpu()
sc = bpy.context.scene
f0 = int(argv[1]) if len(argv) > 1 else sc.frame_start
f1 = int(argv[2]) if len(argv) > 2 else sc.frame_end
if mode == 'preview':
    sc.render.resolution_percentage = 67          # 1920x1080 * 0.67 = 1286x723
    sc.cycles.samples = 8
    sc.render.use_motion_blur = False
else:
    sc.render.resolution_percentage = 100
sc.render.image_settings.file_format = 'PNG'
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
out = os.path.join(root, 'render', mode)
os.makedirs(out, exist_ok=True)
times = []
for f in range(f0, f1 + 1):
    p = os.path.join(out, f'f{f:04d}.png')
    if os.path.exists(p):
        continue
    sc.frame_set(f); sc.render.filepath = p
    t = time.time(); bpy.ops.render.render(write_still=True); times.append(time.time() - t)
    print(f'kare {f}/{f1}  {times[-1]:.1f} sn', flush=True)
if times:
    print(f'\nBITTI: {len(times)} kare, ortalama {sum(times) / len(times):.1f} sn/kare -> {out}\n')
