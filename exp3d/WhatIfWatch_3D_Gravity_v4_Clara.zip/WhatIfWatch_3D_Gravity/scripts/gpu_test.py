# 1) Short GPU check: renders frame 150 at 1920x1080 once with the GPU and reports the time.
# blender.exe -b scene\gravity_test.blend -P scripts\gpu_test.py
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bpy
from gpu_common import enable_gpu
kind, names = enable_gpu()
sc = bpy.context.scene
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
out = os.path.join(root, 'render', 'gpu_test')
os.makedirs(out, exist_ok=True)
sc.frame_set(150)
sc.render.filepath = os.path.join(out, 'gpu_test_f0150.png')
t = time.time()
bpy.ops.render.render(write_still=True)
dt = time.time() - t
msg = f'GPU TEST OK | {kind} | {", ".join(names)} | 1920x1080 | {sc.cycles.samples} samples | {dt:.1f} sn/kare | 312 kare tahmini: {dt * 312 / 60:.0f} dk'
print('\n' + msg + '\n')
open(os.path.join(out, 'gpu_test_sonuc.txt'), 'w', encoding='utf-8').write(msg + '\n')
