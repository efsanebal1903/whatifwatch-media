# 4) Join rendered PNG frames into an H.264 MP4 with Blender's own video editor (no extra software needed).
# blender.exe -b -P scripts\make_mp4.py -- <klasor>   (orn. preview_eevee_hizli)
# Blender 5.0 API: sequence_editor.strips (the old 'sequences' name was removed); image_settings.media_type = 'VIDEO'.
import sys, os, glob
import bpy
argv = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
mode = argv[0] if argv else 'preview_eevee_hizli'
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src = os.path.join(root, 'render', mode)
files = sorted(os.path.basename(p) for p in glob.glob(os.path.join(src, 'f*.png')))
if not files:
    print('PNG kare bulunamadi:', src); raise SystemExit(2)
bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
img = bpy.data.images.load(os.path.join(src, files[0])); w, h = img.size; bpy.data.images.remove(img)
sc.render.fps = 24
sc.render.resolution_x, sc.render.resolution_y, sc.render.resolution_percentage = w, h, 100
se = sc.sequence_editor_create()
st = se.strips.new_image('frames', os.path.join(src, files[0]), 1, 1)
for f in files[1:]:
    st.elements.append(f)
sc.frame_start = 1; sc.frame_end = len(files)
sc.view_settings.view_transform = 'Standard'
ims = sc.render.image_settings
ims.media_type = 'VIDEO'
ims.file_format = 'FFMPEG'
sc.render.ffmpeg.format = 'MPEG4'; sc.render.ffmpeg.codec = 'H264'; sc.render.ffmpeg.constant_rate_factor = 'HIGH'
sc.render.ffmpeg.audio_codec = 'NONE'
out = os.path.join(root, 'render', f'MaxGravity_{mode}_{w}x{h}.mp4')
sc.render.filepath = out
bpy.ops.render.render(animation=True)
print(f'\nMP4 HAZIR: {out} ({len(files)} kare, {len(files) / 24:.2f} sn)\n')
